import { useState, useEffect } from 'react';
import { Bell, X, Check, Calendar, DollarSign, Users, Award, Leaf } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';

interface Notification {
  id: string;
  type: 'payment' | 'contract' | 'event' | 'achievement' | 'carbon' | 'application';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionRequired?: boolean;
}

interface NotificationSystemProps {
  userRole: 'sponsor' | 'volunteer' | 'organizer';
  isDarkMode?: boolean;
}

export default function NotificationSystem({ userRole, isDarkMode }: NotificationSystemProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  // Mock notifications based on user role
  useEffect(() => {
    const mockNotifications: Notification[] = [];

    if (userRole === 'sponsor') {
      mockNotifications.push(
        {
          id: '1',
          type: 'contract',
          title: 'Contract Ready for Signature',
          message: 'Tech Innovation Summit 2024 sponsorship contract is ready for your review',
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          read: false,
          actionRequired: true
        },
        {
          id: '2',
          type: 'carbon',
          title: 'Carbon Footprint Report Available',
          message: 'Your eco-impact report for Corporate Leadership Conference is ready',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
          read: false
        },
        {
          id: '3',
          type: 'achievement',
          title: 'New Eco-Badge Earned!',
          message: 'Congratulations! You earned the "Green Champion" badge for supporting 5 sustainable events',
          timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
          read: true
        }
      );
    } else if (userRole === 'volunteer') {
      mockNotifications.push(
        {
          id: '1',
          type: 'application',
          title: 'Application Accepted',
          message: 'You have been selected for the Tech Innovation Summit 2024! Contract details attached.',
          timestamp: new Date(Date.now() - 15 * 60 * 1000),
          read: false,
          actionRequired: true
        },
        {
          id: '2',
          type: 'achievement',
          title: 'Level Up! 🎉',
          message: 'You reached Level 3 Volunteer! Your dedication is paying off.',
          timestamp: new Date(Date.now() - 45 * 60 * 1000),
          read: false
        },
        {
          id: '3',
          type: 'payment',
          title: 'Payment Received',
          message: '$150 has been credited to your P.E.O.N wallet for Community Health Fair',
          timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
          read: true
        }
      );
    } else if (userRole === 'organizer') {
      mockNotifications.push(
        {
          id: '1',
          type: 'application',
          title: 'New Volunteer Applications',
          message: '5 new volunteers applied for your Annual Tech Conference 2024',
          timestamp: new Date(Date.now() - 10 * 60 * 1000),
          read: false
        },
        {
          id: '2',
          type: 'contract',
          title: 'Sponsor Contract Signed',
          message: 'TechCorp has signed the sponsorship agreement for $10,000',
          timestamp: new Date(Date.now() - 60 * 60 * 1000),
          read: false
        },
        {
          id: '3',
          type: 'payment',
          title: 'Payment Processed',
          message: 'Volunteer payments for Community Health Fair have been processed',
          timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
          read: true
        }
      );
    }

    setNotifications(mockNotifications);
  }, [userRole]);

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, read: true }))
    );
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'payment': return <DollarSign className="h-4 w-4" />;
      case 'contract': return <Check className="h-4 w-4" />;
      case 'event': return <Calendar className="h-4 w-4" />;
      case 'achievement': return <Award className="h-4 w-4" />;
      case 'carbon': return <Leaf className="h-4 w-4" />;
      case 'application': return <Users className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'payment': return 'text-green-600 bg-green-100';
      case 'contract': return 'text-blue-600 bg-blue-100';
      case 'event': return 'text-purple-600 bg-purple-100';
      case 'achievement': return 'text-yellow-600 bg-yellow-100';
      case 'carbon': return 'text-green-600 bg-green-100';
      case 'application': return 'text-indigo-600 bg-indigo-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const formatTimeAgo = (timestamp: Date) => {
    const now = new Date();
    const diff = now.getTime() - timestamp.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="relative p-2 rounded-full"
        >
          <Bell className="h-4 w-4" />
          <AnimatePresence>
            {unreadCount > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full text-xs w-5 h-5 flex items-center justify-center"
              >
                {unreadCount > 9 ? '9+' : unreadCount}
              </motion.div>
            )}
          </AnimatePresence>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-96 p-0" sideOffset={8}>
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">Notifications</h3>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={markAllAsRead}
                className="text-xs"
              >
                Mark all read
              </Button>
            )}
          </div>
        </div>
        <div className="max-h-96 overflow-y-auto">
          <AnimatePresence>
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No notifications yet</p>
              </div>
            ) : (
              notifications.map((notification) => (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={`p-4 border-b border-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer ${
                    !notification.read ? 'bg-blue-50 dark:bg-blue-950/20' : ''
                  }`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-1 rounded-full ${getNotificationColor(notification.type)}`}>
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-sm truncate">
                          {notification.title}
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-auto p-1 hover:bg-gray-200 dark:hover:bg-gray-700"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeNotification(notification.id);
                          }}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {notification.message}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-muted-foreground">
                          {formatTimeAgo(notification.timestamp)}
                        </span>
                        {notification.actionRequired && (
                          <Badge variant="outline" className="text-xs">
                            Action Required
                          </Badge>
                        )}
                        {!notification.read && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </PopoverContent>
    </Popover>
  );
}