import { useState } from 'react';
import { Wallet, CreditCard, ArrowUpRight, ArrowDownLeft, Eye, EyeOff, Plus, Minus, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';

interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'pending';
  title: string;
  amount: number;
  date: Date;
  status: 'completed' | 'pending' | 'failed';
  eventName?: string;
  contractId?: string;
}

interface WalletComponentProps {
  userRole: 'sponsor' | 'volunteer' | 'organizer';
  isDarkMode?: boolean;
}

export default function WalletComponent({ userRole, isDarkMode }: WalletComponentProps) {
  const [balance] = useState<number>(userRole === 'sponsor' ? 25000 : userRole === 'organizer' ? 15000 : 1250);
  const [showBalance, setShowBalance] = useState(false);
  const [isAddFundsOpen, setIsAddFundsOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [addAmount, setAddAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');

  // Mock transactions based on user role
  const getTransactions = (): Transaction[] => {
    if (userRole === 'sponsor') {
      return [
        {
          id: '1',
          type: 'expense',
          title: 'Tech Innovation Summit 2024 - Gold Sponsorship',
          amount: 10000,
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          status: 'completed',
          eventName: 'Tech Innovation Summit 2024',
          contractId: 'CNT-001'
        },
        {
          id: '2',
          type: 'pending',
          title: 'Corporate Leadership Conference - Pending',
          amount: 8000,
          date: new Date(Date.now() - 5 * 60 * 60 * 1000),
          status: 'pending',
          eventName: 'Corporate Leadership Conference',
          contractId: 'CNT-002'
        },
        {
          id: '3',
          type: 'income',
          title: 'Wallet Top-up',
          amount: 20000,
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          status: 'completed'
        }
      ];
    } else if (userRole === 'volunteer') {
      return [
        {
          id: '1',
          type: 'income',
          title: 'Community Health Fair - Volunteer Payment',
          amount: 150,
          date: new Date(Date.now() - 3 * 60 * 60 * 1000),
          status: 'completed',
          eventName: 'Community Health Fair',
          contractId: 'CNT-VOL-001'
        },
        {
          id: '2',
          type: 'pending',
          title: 'Tech Innovation Summit 2024 - Payment Processing',
          amount: 200,
          date: new Date(Date.now() - 30 * 60 * 1000),
          status: 'pending',
          eventName: 'Tech Innovation Summit 2024',
          contractId: 'CNT-VOL-002'
        },
        {
          id: '3',
          type: 'income',
          title: 'Annual Charity Marathon - Completion Bonus',
          amount: 100,
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          status: 'completed',
          eventName: 'Annual Charity Marathon'
        }
      ];
    } else {
      return [
        {
          id: '1',
          type: 'income',
          title: 'TechCorp - Gold Sponsorship Payment',
          amount: 10000,
          date: new Date(Date.now() - 60 * 60 * 1000),
          status: 'completed',
          eventName: 'Annual Tech Conference 2024',
          contractId: 'CNT-001'
        },
        {
          id: '2',
          type: 'expense',
          title: 'Volunteer Payments - Community Health Fair',
          amount: 1200,
          date: new Date(Date.now() - 6 * 60 * 60 * 1000),
          status: 'completed',
          eventName: 'Community Health Fair'
        },
        {
          id: '3',
          type: 'expense',
          title: 'Platform Service Fee',
          amount: 50,
          date: new Date(Date.now() - 24 * 60 * 60 * 1000),
          status: 'completed'
        }
      ];
    }
  };

  const transactions = getTransactions();

  const handleAddFunds = () => {
    if (!addAmount || !paymentMethod) {
      toast.error('Please fill in all fields');
      return;
    }
    toast.success(`Successfully added $${addAmount} to your wallet`);
    setIsAddFundsOpen(false);
    setAddAmount('');
    setPaymentMethod('');
  };

  const handleWithdraw = () => {
    if (!withdrawAmount || !paymentMethod) {
      toast.error('Please fill in all fields');
      return;
    }
    if (parseFloat(withdrawAmount) > balance) {
      toast.error('Insufficient balance');
      return;
    }
    toast.success(`Withdrawal of $${withdrawAmount} initiated`);
    setIsWithdrawOpen(false);
    setWithdrawAmount('');
    setPaymentMethod('');
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'income': return <ArrowDownLeft className="h-4 w-4 text-green-600" />;
      case 'expense': return <ArrowUpRight className="h-4 w-4 text-red-600" />;
      case 'pending': return <ArrowUpRight className="h-4 w-4 text-yellow-600" />;
      default: return <CreditCard className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            P.E.O.N Wallet
          </CardTitle>
          <div className="flex gap-2">
            <Dialog open={isAddFundsOpen} onOpenChange={setIsAddFundsOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Funds
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Funds to Wallet</DialogTitle>
                  <DialogDescription>
                    Top up your P.E.O.N wallet for seamless transactions
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (USD)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="1000"
                      value={addAmount}
                      onChange={(e) => setAddAmount(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Payment Method</Label>
                    <Select onValueChange={setPaymentMethod}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="card">Credit/Debit Card</SelectItem>
                        <SelectItem value="bank">Bank Transfer</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="crypto">Cryptocurrency</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button onClick={handleAddFunds} className="flex-1">
                      Add Funds
                    </Button>
                    <Button variant="outline" onClick={() => setIsAddFundsOpen(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            
            <Dialog open={isWithdrawOpen} onOpenChange={setIsWithdrawOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Minus className="h-4 w-4 mr-2" />
                  Withdraw
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Withdraw Funds</DialogTitle>
                  <DialogDescription>
                    Transfer funds from your P.E.O.N wallet to your bank account
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="withdraw-amount">Amount (USD)</Label>
                    <Input
                      id="withdraw-amount"
                      type="number"
                      placeholder="500"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      max={balance}
                    />
                    <p className="text-sm text-muted-foreground">Available: ${balance.toLocaleString()}</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Withdrawal Method</Label>
                    <Select onValueChange={setPaymentMethod}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select withdrawal method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bank">Bank Transfer</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="check">Check</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button onClick={handleWithdraw} className="flex-1">
                      Withdraw
                    </Button>
                    <Button variant="outline" onClick={() => setIsWithdrawOpen(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Balance Display */}
        <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Current Balance</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowBalance(!showBalance)}
              className="text-white hover:bg-white/20"
            >
              {showBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          </div>
          <div className="text-3xl font-bold">
            {showBalance ? `$${balance.toLocaleString()}` : '••••••'}
          </div>
          <p className="text-blue-100 text-sm mt-2">P.E.O.N Digital Wallet</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            className="flex flex-col gap-2 h-auto p-4"
            onClick={() => window.open('/payment-gateway', '_blank')}
          >
            <ExternalLink className="h-5 w-5" />
            <span>Payment Gateway</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col gap-2 h-auto p-4"
            onClick={() => window.open('/transaction-history', '_blank')}
          >
            <CreditCard className="h-5 w-5" />
            <span>Full History</span>
          </Button>
        </div>

        {/* Recent Transactions */}
        <div>
          <h4 className="font-medium mb-3">Recent Transactions</h4>
          <div className="space-y-3">
            {transactions.slice(0, 5).map((transaction) => (
              <motion.div
                key={transaction.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  {getTransactionIcon(transaction.type)}
                  <div>
                    <p className="font-medium text-sm">{transaction.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {transaction.date.toLocaleDateString()} at {transaction.date.toLocaleTimeString()}
                    </p>
                    {transaction.eventName && (
                      <p className="text-xs text-blue-600">{transaction.eventName}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-medium ${
                    transaction.type === 'income' ? 'text-green-600' : 
                    transaction.type === 'expense' ? 'text-red-600' : 'text-yellow-600'
                  }`}>
                    {transaction.type === 'income' ? '+' : '-'}${transaction.amount.toLocaleString()}
                  </p>
                  <Badge variant="outline" className={`text-xs ${getStatusColor(transaction.status)}`}>
                    {transaction.status}
                  </Badge>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Wallet Features */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t">
          <div className="text-center">
            <div className="bg-green-100 dark:bg-green-900/20 rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-2">
              <ArrowDownLeft className="h-5 w-5 text-green-600" />
            </div>
            <p className="text-sm font-medium">Instant Deposits</p>
            <p className="text-xs text-muted-foreground">Real-time funding</p>
          </div>
          <div className="text-center">
            <div className="bg-blue-100 dark:bg-blue-900/20 rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-2">
              <CreditCard className="h-5 w-5 text-blue-600" />
            </div>
            <p className="text-sm font-medium">Secure Payments</p>
            <p className="text-xs text-muted-foreground">Encrypted transactions</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 dark:bg-purple-900/20 rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-2">
              <Wallet className="h-5 w-5 text-purple-600" />
            </div>
            <p className="text-sm font-medium">Multi-Currency</p>
            <p className="text-xs text-muted-foreground">Global support</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}