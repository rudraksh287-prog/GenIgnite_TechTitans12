import { Users, Star, Calendar, Moon, Sun, Sparkles, ArrowRight, Heart, Target } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface LandingPageProps {
  onRoleSelect: (role: string) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export default function LandingPage({ onRoleSelect, isDarkMode, toggleDarkMode }: LandingPageProps) {
  const roles = [
    {
      id: 'sponsor',
      title: 'Sponsor',
      description: 'Fund and support amazing events while growing your brand visibility and community impact',
      icon: Star,
      features: [
        'Browse events matching your interests',
        'Connect with passionate organizers',
        'Track your sponsorship impact',
        'Build meaningful brand recognition'
      ],
      color: 'bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/30 border-blue-200 dark:border-blue-800 hover:from-blue-100 hover:to-indigo-200 dark:hover:from-blue-900/30 dark:hover:to-indigo-900/40',
      buttonColor: 'bg-blue-600 hover:bg-blue-700 text-white',
      image: 'https://images.unsplash.com/photo-1591453214154-c95db71dbd83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjBzcG9uc29yJTIwaGFuZHNoYWtlJTIwcGFydG5lcnNoaXB8ZW58MXx8fHwxNzU4MzgwMDYwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      id: 'organizer',
      title: 'Organizer/Manager',
      description: 'Create and manage extraordinary events while connecting with sponsors and dedicated volunteers',
      icon: Calendar,
      features: [
        'Create and manage events seamlessly',
        'Find passionate sponsors for your vision',
        'Recruit skilled volunteers',
        'Track event success metrics'
      ],
      color: 'bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-900/20 dark:to-emerald-900/30 border-green-200 dark:border-green-800 hover:from-green-100 hover:to-emerald-200 dark:hover:from-green-900/30 dark:hover:to-emerald-900/40',
      buttonColor: 'bg-green-600 hover:bg-green-700 text-white',
      image: 'https://images.unsplash.com/photo-1531058020387-3be344556be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG5ldHdvcmtpbmclMjBjb25mZXJlbmNlJTIwcGVvcGxlfGVufDF8fHx8MTc1ODM4MDA1NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      id: 'volunteer',
      title: 'Volunteer',
      description: 'Contribute your skills and passion to meaningful events while building connections in your community',
      icon: Users,
      features: [
        'Discover impactful local events',
        'Use your unique skills to help',
        'Build valuable experience',
        'Make a lasting difference'
      ],
      color: 'bg-gradient-to-br from-purple-50 to-violet-100 dark:from-purple-900/20 dark:to-violet-900/30 border-purple-200 dark:border-purple-800 hover:from-purple-100 hover:to-violet-200 dark:hover:from-purple-900/30 dark:hover:to-violet-900/40',
      buttonColor: 'bg-purple-600 hover:bg-purple-700 text-white',
      image: 'https://images.unsplash.com/photo-1560220604-1985ebfe28b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2b2x1bnRlZXIlMjB0ZWFtJTIwaGVscGluZyUyMGNvbW11bml0eXxlbnwxfHx8fDE3NTgzODAwNTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const cardVariants = {
    hidden: { y: 50, opacity: 0, scale: 0.95 },
    visible: {
      y: 0,
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    },
    hover: {
      y: -10,
      scale: 1.03,
      transition: {
        duration: 0.3,
        ease: "easeInOut"
      }
    }
  };

  const sparkleVariants = {
    animate: {
      scale: [1, 1.2, 1],
      rotate: [0, 180, 360],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-900 dark:via-slate-800 dark:to-blue-900">
      {/* Header with Dark Mode Toggle */}
      <motion.header 
        className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-gray-200/50 dark:border-gray-700/50"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.div 
            className="flex items-center gap-3"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="relative"
              variants={sparkleVariants}
              animate="animate"
            >
              <Sparkles className="h-8 w-8 text-gradient-to-r from-blue-600 to-purple-600" />
            </motion.div>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent">
                P.E.O.N
              </h1>
              <p className="text-xs text-muted-foreground -mt-1">Platform for Event, Organizers and Networking</p>
            </div>
          </motion.div>
          
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleDarkMode}
              className="p-2 rounded-full"
            >
              {isDarkMode ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : (
                <Moon className="h-5 w-5 text-slate-600" />
              )}
            </Button>
          </motion.div>
        </div>
      </motion.header>

      <div className="container mx-auto px-4 py-20">
        {/* Hero Section */}
        <motion.div 
          className="text-center mb-20 pt-16"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            variants={itemVariants}
            className="relative inline-block mb-6"
          >
            <motion.div
              className="absolute -top-2 -right-2"
              variants={sparkleVariants}
              animate="animate"
            >
              <Sparkles className="h-6 w-6 text-yellow-400" />
            </motion.div>
            <h1 className="text-5xl md:text-7xl bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent mb-2">
              P.E.O.N
            </h1>
          </motion.div>
          <motion.h2 
            variants={itemVariants}
            className="text-xl md:text-2xl text-muted-foreground mb-6"
          >
            Platform for Event, Organizers and Networking
          </motion.h2>
          <motion.p 
            variants={itemVariants}
            className="max-w-3xl mx-auto text-lg text-muted-foreground leading-relaxed"
          >
            Unite sponsors, organizers, and volunteers in one powerful ecosystem. 
            Create extraordinary events, build meaningful connections, and make lasting impact in your community.
          </motion.p>
          
          <motion.div
            variants={itemVariants}
            className="flex justify-center mt-8"
          >
            <motion.div
              animate={{ 
                y: [0, -10, 0],
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <ArrowRight className="h-6 w-6 text-primary" />
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Role Selection Cards */}
        <motion.div 
          className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto mb-20"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {roles.map((role, index) => {
            const IconComponent = role.icon;
            return (
              <motion.div
                key={role.id}
                variants={cardVariants}
                whileHover="hover"
                className="group"
              >
                <Card 
                  className={`${role.color} transition-all duration-500 hover:shadow-2xl cursor-pointer transform perspective-1000 h-full border-2 overflow-hidden relative`}
                  onClick={() => onRoleSelect(role.id)}
                >
                  {/* Background Image */}
                  <div className="absolute top-0 right-0 w-32 h-32 opacity-10 group-hover:opacity-20 transition-opacity duration-300 overflow-hidden rounded-bl-3xl">
                    <ImageWithFallback
                      src={role.image}
                      alt={`${role.title} background`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <CardHeader className="text-center pb-4 relative z-10">
                    <motion.div 
                      className="flex justify-center mb-4"
                      whileHover={{ rotate: 360, scale: 1.2 }}
                      transition={{ duration: 0.5 }}
                    >
                      <div className="p-4 bg-white/50 dark:bg-slate-800/50 rounded-full shadow-lg backdrop-blur-sm">
                        <IconComponent className="h-10 w-10 text-primary" />
                      </div>
                    </motion.div>
                    <CardTitle className="text-2xl mb-2">{role.title}</CardTitle>
                    <CardDescription className="text-center leading-relaxed">
                      {role.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="relative z-10">
                    <ul className="space-y-3 mb-8">
                      {role.features.map((feature, featureIndex) => (
                        <motion.li 
                          key={featureIndex} 
                          className="flex items-start text-sm"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 * featureIndex }}
                        >
                          <motion.div 
                            className="w-2 h-2 bg-gradient-to-r from-primary to-purple-600 rounded-full mr-3 mt-2 flex-shrink-0"
                            whileHover={{ scale: 1.5 }}
                          />
                          {feature}
                        </motion.li>
                      ))}
                    </ul>
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Button 
                        className={`w-full ${role.buttonColor} shadow-lg hover:shadow-xl transition-all duration-300`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onRoleSelect(role.id);
                        }}
                      >
                        <span className="mr-2">Get Started as {role.title}</span>
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Enhanced Features Section */}
        <motion.div 
          className="mt-24 text-center"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <motion.h2 variants={itemVariants} className="mb-12 bg-gradient-to-r from-slate-700 to-slate-900 dark:from-slate-200 dark:to-white bg-clip-text text-transparent">
            Why Choose P.E.O.N?
          </motion.h2>
          <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto">
            {[
              {
                icon: Users,
                title: "Connected Community",
                description: "Foster meaningful relationships between sponsors, organizers, and volunteers in one unified ecosystem",
                color: "text-blue-600"
              },
              {
                icon: Target,
                title: "Smart Matching",
                description: "Intelligent algorithms connect the right people with the perfect events based on interests and location",
                color: "text-green-600"
              },
              {
                icon: Heart,
                title: "Impact Driven",
                description: "Comprehensive tools and analytics to measure and maximize the positive impact of every event",
                color: "text-purple-600"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                variants={cardVariants}
                whileHover="hover"
                className="p-8 rounded-2xl bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border border-white/20 dark:border-slate-700/50 group"
              >
                <motion.div 
                  className={`w-16 h-16 ${feature.color === 'text-blue-600' ? 'bg-blue-100 dark:bg-blue-900/30' : feature.color === 'text-green-600' ? 'bg-green-100 dark:bg-green-900/30' : 'bg-purple-100 dark:bg-purple-900/30'} rounded-2xl flex items-center justify-center mx-auto mb-6`}
                  whileHover={{ rotate: [0, -5, 5, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  <feature.icon className={`h-8 w-8 ${feature.color}`} />
                </motion.div>
                <h3 className="mb-4">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          className="text-center mt-20 p-12 rounded-3xl bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-green-500/10 dark:from-blue-900/20 dark:via-purple-900/20 dark:to-green-900/20 border border-white/20 dark:border-slate-700/30 backdrop-blur-sm"
          variants={itemVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <motion.div
            className="mb-6"
            animate={{ 
              scale: [1, 1.1, 1],
            }}
            transition={{ 
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Sparkles className="h-12 w-12 text-gradient-to-r from-blue-600 to-purple-600 mx-auto" />
          </motion.div>
          <h3 className="mb-4 bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent">
            Ready to Transform Your Event Experience?
          </h3>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of sponsors, organizers, and volunteers who are already creating extraordinary events and building stronger communities.
          </p>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 hover:from-blue-700 hover:via-purple-700 hover:to-green-700 text-white shadow-2xl px-8 py-3"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            >
              Start Your Journey
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}