import { useState } from 'react';
import { ArrowLeft, Calendar, Building, Moon, Sun, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { User } from '../App';

interface OrganizerSignupProps {
  onSignupComplete: (user: User) => void;
  onBack: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export default function OrganizerSignup({ onSignupComplete, onBack, isDarkMode, toggleDarkMode }: OrganizerSignupProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    organizationName: '',
    website: '',
    phone: '',
    description: '',
    eventTypes: [] as string[],
    experience: '',
    previousEvents: ''
  });

  const eventTypes = [
    'Corporate Events',
    'Conferences & Seminars',
    'Trade Shows & Exhibitions',
    'Sports Events',
    'Concerts & Entertainment',
    'Community Events',
    'Charity & Fundraising',
    'Weddings & Private Events'
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCheckboxChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      eventTypes: prev.eventTypes.includes(value)
        ? prev.eventTypes.filter(item => item !== value)
        : [...prev.eventTypes, value]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 1) {
      if (!formData.name || !formData.email || !formData.password || !formData.organizationName) {
        toast.error('Please fill in all required fields');
        return;
      }
      setStep(2);
    } else {
      if (formData.eventTypes.length === 0) {
        toast.error('Please select at least one event type');
        return;
      }
      
      const user: User = {
        id: Math.random().toString(36).substr(2, 9),
        role: 'organizer' as const,
        name: formData.name,
        email: formData.email,
        organizationName: formData.organizationName,
        website: formData.website,
        phone: formData.phone,
        description: formData.description,
        eventTypes: formData.eventTypes,
        experience: formData.experience,
        previousEvents: formData.previousEvents
      };
      
      toast.success('Organizer account created successfully!');
      onSignupComplete(user);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white dark:from-green-900 dark:to-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5 dark:opacity-10"></div>
      <motion.div
        className="absolute top-20 left-20 w-40 h-40 bg-green-200/20 dark:bg-green-800/20 rounded-full blur-3xl"
        animate={{ x: [0, 60, 0], y: [0, -40, 0] }}
        transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Header */}
      <motion.header 
        className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-gray-200/50 dark:border-gray-700/50"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Sparkles className="h-6 w-6 text-green-600" />
            <div>
              <h1 className="text-lg bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent">
                P.E.O.N
              </h1>
              <p className="text-xs text-muted-foreground -mt-1">Platform for Event, Organizers and Networking</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleDarkMode}
            className="p-2 rounded-full"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4 text-yellow-500" />
            ) : (
              <Moon className="h-4 w-4 text-slate-600" />
            )}
          </Button>
        </div>
      </motion.header>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-2xl relative z-10 mt-20"
      >
        <Card className="backdrop-blur-md bg-white/90 dark:bg-slate-800/90 border border-white/20 dark:border-slate-700/50 shadow-2xl">
        <CardHeader>
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={step === 1 ? onBack : () => setStep(1)}
              className="p-2"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-green-600" />
                Organizer Registration
              </CardTitle>
              <CardDescription>
                {step === 1 ? 'Create your organizer account' : 'Tell us about your experience'}
              </CardDescription>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <div className={`h-2 rounded-full flex-1 ${step >= 1 ? 'bg-green-600' : 'bg-gray-200'}`} />
            <div className={`h-2 rounded-full flex-1 ${step >= 2 ? 'bg-green-600' : 'bg-gray-200'}`} />
          </div>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            {step === 1 ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="john@organization.com"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    placeholder="Create a secure password"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="organizationName">Organization Name *</Label>
                    <div className="relative">
                      <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="organizationName"
                        value={formData.organizationName}
                        onChange={(e) => handleInputChange('organizationName', e.target.value)}
                        placeholder="Event Co."
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="website">Organization Website</Label>
                  <Input
                    id="website"
                    value={formData.website}
                    onChange={(e) => handleInputChange('website', e.target.value)}
                    placeholder="https://organization.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Organization Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Briefly describe your organization and event planning goals..."
                    rows={3}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="space-y-4">
                  <Label>What types of events do you organize? *</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {eventTypes.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <Checkbox
                          id={type}
                          checked={formData.eventTypes.includes(type)}
                          onCheckedChange={() => handleCheckboxChange(type)}
                        />
                        <Label htmlFor={type} className="text-sm">{type}</Label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="experience">Years of Event Organization Experience</Label>
                  <Input
                    id="experience"
                    value={formData.experience}
                    onChange={(e) => handleInputChange('experience', e.target.value)}
                    placeholder="5 years"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="previousEvents">Previous Notable Events</Label>
                  <Textarea
                    id="previousEvents"
                    value={formData.previousEvents}
                    onChange={(e) => handleInputChange('previousEvents', e.target.value)}
                    placeholder="Describe some of the events you've organized in the past..."
                    rows={4}
                  />
                </div>
              </>
            )}
            
            <Button type="submit" className="w-full">
              {step === 1 ? 'Continue' : 'Create Organizer Account'}
            </Button>
          </CardContent>
        </form>
      </Card>
      </motion.div>
    </div>
  );
}