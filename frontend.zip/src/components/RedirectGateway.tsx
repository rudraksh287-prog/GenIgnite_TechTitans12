import { useState } from 'react';
import { ExternalLink, CreditCard, Calendar, MessageCircle, Phone, Mail, Video, Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';

interface RedirectService {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  category: 'payment' | 'calendar' | 'communication' | 'social';
  url?: string;
  requiresAuth?: boolean;
  popular?: boolean;
}

interface RedirectGatewayProps {
  eventContext?: {
    eventName: string;
    organizerName: string;
    eventDate: string;
  };
  isDarkMode?: boolean;
}

export default function RedirectGateway({ eventContext, isDarkMode }: RedirectGatewayProps) {
  const [selectedService, setSelectedService] = useState<RedirectService | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionData, setConnectionData] = useState({
    message: '',
    meetingTitle: '',
    paymentAmount: '',
    paymentDescription: ''
  });

  const services: RedirectService[] = [
    // Payment Services
    {
      id: 'stripe',
      name: 'Stripe',
      description: 'Secure payment processing for event transactions',
      icon: <CreditCard className="h-5 w-5" />,
      category: 'payment',
      url: 'https://stripe.com',
      popular: true
    },
    {
      id: 'paypal',
      name: 'PayPal',
      description: 'Send and receive payments globally',
      icon: <CreditCard className="h-5 w-5" />,
      category: 'payment',
      url: 'https://paypal.com'
    },
    {
      id: 'square',
      name: 'Square',
      description: 'Point-of-sale and online payment solutions',
      icon: <CreditCard className="h-5 w-5" />,
      category: 'payment',
      url: 'https://squareup.com'
    },

    // Calendar Services
    {
      id: 'google-calendar',
      name: 'Google Calendar',
      description: 'Schedule meetings and manage events',
      icon: <Calendar className="h-5 w-5" />,
      category: 'calendar',
      url: 'https://calendar.google.com',
      popular: true
    },
    {
      id: 'outlook',
      name: 'Outlook Calendar',
      description: 'Microsoft calendar and scheduling',
      icon: <Calendar className="h-5 w-5" />,
      category: 'calendar',
      url: 'https://outlook.com'
    },
    {
      id: 'calendly',
      name: 'Calendly',
      description: 'Easy appointment scheduling',
      icon: <Calendar className="h-5 w-5" />,
      category: 'calendar',
      url: 'https://calendly.com',
      popular: true
    },

    // Communication Services
    {
      id: 'zoom',
      name: 'Zoom',
      description: 'Video conferencing and online meetings',
      icon: <Video className="h-5 w-5" />,
      category: 'communication',
      url: 'https://zoom.us',
      popular: true
    },
    {
      id: 'microsoft-teams',
      name: 'Microsoft Teams',
      description: 'Collaboration and video meetings',
      icon: <Video className="h-5 w-5" />,
      category: 'communication',
      url: 'https://teams.microsoft.com'
    },
    {
      id: 'slack',
      name: 'Slack',
      description: 'Team communication and messaging',
      icon: <MessageCircle className="h-5 w-5" />,
      category: 'communication',
      url: 'https://slack.com'
    },
    {
      id: 'discord',
      name: 'Discord',
      description: 'Voice, video, and text communication',
      icon: <MessageCircle className="h-5 w-5" />,
      category: 'communication',
      url: 'https://discord.com'
    },

    // Social Media Services
    {
      id: 'linkedin',
      name: 'LinkedIn',
      description: 'Professional networking and messaging',
      icon: <Globe className="h-5 w-5" />,
      category: 'social',
      url: 'https://linkedin.com',
      popular: true
    },
    {
      id: 'twitter',
      name: 'Twitter/X',
      description: 'Social media and public communication',
      icon: <Globe className="h-5 w-5" />,
      category: 'social',
      url: 'https://twitter.com'
    },
    {
      id: 'whatsapp',
      name: 'WhatsApp',
      description: 'Instant messaging and calls',
      icon: <Phone className="h-5 w-5" />,
      category: 'social',
      url: 'https://web.whatsapp.com'
    },
    {
      id: 'telegram',
      name: 'Telegram',
      description: 'Secure messaging platform',
      icon: <MessageCircle className="h-5 w-5" />,
      category: 'social',
      url: 'https://telegram.org'
    }
  ];

  const handleConnect = (service: RedirectService) => {
    setSelectedService(service);
    setIsConnecting(true);

    // Simulate connection process
    setTimeout(() => {
      let redirectUrl = service.url;
      
      // Customize redirect URL based on service and context
      if (service.category === 'calendar' && eventContext) {
        const startDate = new Date(eventContext.eventDate);
        const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000); // 2 hours later
        
        if (service.id === 'google-calendar') {
          const params = new URLSearchParams({
            action: 'TEMPLATE',
            text: eventContext.eventName,
            dates: `${startDate.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '')}/${endDate.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '')}`,
            details: `Event organized by ${eventContext.organizerName}`
          });
          redirectUrl = `https://calendar.google.com/calendar/render?${params.toString()}`;
        }
      } else if (service.category === 'communication' && connectionData.message) {
        if (service.id === 'zoom' && connectionData.meetingTitle) {
          redirectUrl = `https://zoom.us/start/videomeeting`;
        } else if (service.id === 'slack') {
          redirectUrl = `https://slack.com/intl/en-in/`;
        }
      } else if (service.category === 'payment' && connectionData.paymentAmount) {
        if (service.id === 'stripe') {
          redirectUrl = `https://checkout.stripe.com/`;
        } else if (service.id === 'paypal') {
          redirectUrl = `https://www.paypal.com/checkoutnow`;
        }
      }

      // Open in new tab
      window.open(redirectUrl, '_blank', 'noopener,noreferrer');
      
      setIsConnecting(false);
      setSelectedService(null);
      setConnectionData({
        message: '',
        meetingTitle: '',
        paymentAmount: '',
        paymentDescription: ''
      });
      
      toast.success(`Redirected to ${service.name}`);
    }, 1500);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'payment': return <CreditCard className="h-4 w-4" />;
      case 'calendar': return <Calendar className="h-4 w-4" />;
      case 'communication': return <MessageCircle className="h-4 w-4" />;
      case 'social': return <Globe className="h-4 w-4" />;
      default: return <ExternalLink className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'payment': return 'text-green-600 bg-green-100';
      case 'calendar': return 'text-blue-600 bg-blue-100';
      case 'communication': return 'text-purple-600 bg-purple-100';
      case 'social': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const groupedServices = services.reduce((groups, service) => {
    const category = service.category;
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(service);
    return groups;
  }, {} as Record<string, RedirectService[]>);

  const categoryNames = {
    payment: 'Payment Gateways',
    calendar: 'Calendar & Scheduling',
    communication: 'Communication',
    social: 'Social Media'
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ExternalLink className="h-5 w-5" />
          Quick Connect Gateway
        </CardTitle>
        <CardDescription>
          Seamlessly connect to external platforms for payments, scheduling, and communication
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {Object.entries(groupedServices).map(([category, categoryServices]) => (
            <div key={category}>
              <div className="flex items-center gap-2 mb-3">
                {getCategoryIcon(category)}
                <h3 className="font-medium">{categoryNames[category as keyof typeof categoryNames]}</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {categoryServices.map((service, index) => (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Dialog>
                      <DialogTrigger asChild>
                        <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 hover:border-blue-200">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                {service.icon}
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-medium">{service.name}</h4>
                                    {service.popular && (
                                      <Badge variant="outline" className="text-xs">
                                        Popular
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-sm text-muted-foreground">{service.description}</p>
                                </div>
                              </div>
                              <Badge className={getCategoryColor(service.category)}>
                                {getCategoryIcon(service.category)}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      </DialogTrigger>
                      
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            {service.icon}
                            Connect to {service.name}
                          </DialogTitle>
                          <DialogDescription>
                            Configure your connection to {service.name} for this event
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="space-y-4">
                          {eventContext && (
                            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                              <h4 className="font-medium mb-2">Event Context</h4>
                              <div className="text-sm space-y-1">
                                <p><strong>Event:</strong> {eventContext.eventName}</p>
                                <p><strong>Organizer:</strong> {eventContext.organizerName}</p>
                                <p><strong>Date:</strong> {new Date(eventContext.eventDate).toLocaleDateString()}</p>
                              </div>
                            </div>
                          )}

                          {service.category === 'payment' && (
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label htmlFor="payment-amount">Payment Amount (USD)</Label>
                                <Input
                                  id="payment-amount"
                                  type="number"
                                  placeholder="100.00"
                                  value={connectionData.paymentAmount}
                                  onChange={(e) => setConnectionData(prev => ({ ...prev, paymentAmount: e.target.value }))}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="payment-description">Payment Description</Label>
                                <Input
                                  id="payment-description"
                                  placeholder="Event sponsorship fee"
                                  value={connectionData.paymentDescription}
                                  onChange={(e) => setConnectionData(prev => ({ ...prev, paymentDescription: e.target.value }))}
                                />
                              </div>
                            </div>
                          )}

                          {service.category === 'calendar' && (
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label htmlFor="meeting-title">Meeting/Event Title</Label>
                                <Input
                                  id="meeting-title"
                                  placeholder={eventContext?.eventName || "Meeting with organizer"}
                                  value={connectionData.meetingTitle}
                                  onChange={(e) => setConnectionData(prev => ({ ...prev, meetingTitle: e.target.value }))}
                                />
                              </div>
                            </div>
                          )}

                          {service.category === 'communication' && (
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label htmlFor="message">Message/Topic</Label>
                                <Textarea
                                  id="message"
                                  placeholder="Hi, I'd like to discuss the event details..."
                                  value={connectionData.message}
                                  onChange={(e) => setConnectionData(prev => ({ ...prev, message: e.target.value }))}
                                  rows={3}
                                />
                              </div>
                            </div>
                          )}

                          <div className="flex gap-2 pt-4">
                            <Button 
                              onClick={() => handleConnect(service)}
                              disabled={isConnecting}
                              className="flex-1"
                            >
                              {isConnecting ? (
                                <motion.div
                                  animate={{ rotate: 360 }}
                                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                                  className="mr-2"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </motion.div>
                              ) : (
                                <ExternalLink className="h-4 w-4 mr-2" />
                              )}
                              {isConnecting ? 'Connecting...' : `Connect to ${service.name}`}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
          
          {/* Recent Connections */}
          <div className="mt-6 pt-6 border-t">
            <h3 className="font-medium mb-3">Recent Connections</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-blue-600" />
                  <div>
                    <p className="font-medium text-sm">Google Calendar</p>
                    <p className="text-xs text-muted-foreground">Event scheduled for Tech Innovation Summit</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">2 hours ago</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <CreditCard className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="font-medium text-sm">Stripe Payment</p>
                    <p className="text-xs text-muted-foreground">$10,000 sponsorship payment processed</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">1 day ago</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}