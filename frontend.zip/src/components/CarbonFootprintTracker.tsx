import { useState, useEffect } from 'react';
import { Leaf, Award, TrendingDown, BarChart3, Download, Calendar, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CarbonData {
  eventId: string;
  eventName: string;
  eventDate: Date;
  totalEmissions: number; // kg CO2
  offsetCredits: number; // kg CO2
  netImpact: number; // kg CO2
  breakdown: {
    venue: number;
    transportation: number;
    catering: number;
    materials: number;
    waste: number;
  };
  offsetMethods: string[];
}

interface EcoBadge {
  id: string;
  name: string;
  description: string;
  icon: string;
  criteria: string;
  earned: boolean;
  earnedDate?: Date;
  level: 'bronze' | 'silver' | 'gold' | 'platinum';
}

interface CarbonFootprintTrackerProps {
  isDarkMode?: boolean;
}

export default function CarbonFootprintTracker({ isDarkMode }: CarbonFootprintTrackerProps) {
  const [carbonData, setCarbonData] = useState<CarbonData[]>([]);
  const [ecoBadges, setEcoBadges] = useState<EcoBadge[]>([]);
  const [totalOffset, setTotalOffset] = useState(0);
  const [totalEmissions, setTotalEmissions] = useState(0);

  useEffect(() => {
    // Mock carbon data for sponsored events
    const mockCarbonData: CarbonData[] = [
      {
        eventId: '1',
        eventName: 'Tech Innovation Summit 2024',
        eventDate: new Date('2024-03-15'),
        totalEmissions: 2500,
        offsetCredits: 3000,
        netImpact: -500, // Net positive (offset more than emitted)
        breakdown: {
          venue: 800,
          transportation: 900,
          catering: 400,
          materials: 250,
          waste: 150
        },
        offsetMethods: ['Renewable energy credits', 'Tree planting', 'Carbon capture technology']
      },
      {
        eventId: '2',
        eventName: 'Corporate Leadership Conference',
        eventDate: new Date('2024-04-22'),
        totalEmissions: 1800,
        offsetCredits: 2200,
        netImpact: -400,
        breakdown: {
          venue: 600,
          transportation: 700,
          catering: 300,
          materials: 150,
          waste: 50
        },
        offsetMethods: ['Solar panel installation', 'Forest conservation', 'Clean transportation']
      },
      {
        eventId: '3',
        eventName: 'Charity Gala for Education',
        eventDate: new Date('2024-05-10'),
        totalEmissions: 1200,
        offsetCredits: 1500,
        netImpact: -300,
        breakdown: {
          venue: 400,
          transportation: 450,
          catering: 200,
          materials: 100,
          waste: 50
        },
        offsetMethods: ['Wind energy projects', 'Wetland restoration']
      }
    ];

    setCarbonData(mockCarbonData);
    
    const totalEmitted = mockCarbonData.reduce((sum, data) => sum + data.totalEmissions, 0);
    const totalOffsetted = mockCarbonData.reduce((sum, data) => sum + data.offsetCredits, 0);
    
    setTotalEmissions(totalEmitted);
    setTotalOffset(totalOffsetted);
  }, []);

  useEffect(() => {
    // Mock eco badges
    const mockEcoBadges: EcoBadge[] = [
      {
        id: '1',
        name: 'Carbon Neutral Champion',
        description: 'Achieved carbon neutrality for 3 consecutive events',
        icon: '🌱',
        criteria: 'Offset 100% of event emissions for 3 events',
        earned: true,
        earnedDate: new Date('2024-05-15'),
        level: 'gold'
      },
      {
        id: '2',
        name: 'Green Innovator',
        description: 'Sponsored events with innovative sustainability practices',
        icon: '💡',
        criteria: 'Support events with 3+ green initiatives',
        earned: true,
        earnedDate: new Date('2024-04-25'),
        level: 'silver'
      },
      {
        id: '3',
        name: 'Climate Guardian',
        description: 'Offset more carbon than generated across all events',
        icon: '🛡️',
        criteria: 'Achieve net negative carbon footprint',
        earned: true,
        earnedDate: new Date('2024-06-01'),
        level: 'platinum'
      },
      {
        id: '4',
        name: 'Sustainability Pioneer',
        description: 'First sponsor to achieve 150% carbon offset ratio',
        icon: '🏆',
        criteria: 'Offset 150% of total emissions in a single event',
        earned: false,
        level: 'platinum'
      },
      {
        id: '5',
        name: 'Eco Ambassador',
        description: 'Promote environmental awareness through event sponsorship',
        icon: '🌍',
        criteria: 'Sponsor 5 environmental or sustainability-focused events',
        earned: false,
        level: 'gold'
      },
      {
        id: '6',
        name: 'Green Starter',
        description: 'Take the first step towards carbon-conscious sponsorship',
        icon: '🌿',
        criteria: 'Offset carbon for your first sponsored event',
        earned: true,
        earnedDate: new Date('2024-03-20'),
        level: 'bronze'
      }
    ];

    setEcoBadges(mockEcoBadges);
  }, []);

  const getBadgeLevelColor = (level: string) => {
    switch (level) {
      case 'bronze': return 'text-orange-600 bg-orange-100 border-orange-200';
      case 'silver': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'gold': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'platinum': return 'text-purple-600 bg-purple-100 border-purple-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const calculateCarbonSavings = () => {
    const netImpact = totalOffset - totalEmissions;
    return netImpact;
  };

  const getOffsetPercentage = () => {
    if (totalEmissions === 0) return 0;
    return (totalOffset / totalEmissions) * 100;
  };

  const generateReport = () => {
    // Simulate report generation
    const reportData = {
      totalEmissions,
      totalOffset,
      netImpact: calculateCarbonSavings(),
      eventsAnalyzed: carbonData.length,
      badgesEarned: ecoBadges.filter(badge => badge.earned).length
    };
    
    console.log('Generating carbon report:', reportData);
    // In a real app, this would trigger a PDF download
    alert('Carbon footprint report downloaded! Check your downloads folder.');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Leaf className="h-5 w-5 text-green-600" />
          Carbon Impact Dashboard
        </CardTitle>
        <CardDescription>
          Track your environmental impact and earn eco-badges for sustainable sponsorship
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="details">Event Details</TabsTrigger>
            <TabsTrigger value="badges">Eco-Badges</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Carbon Impact Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingDown className="h-5 w-5 text-green-600" />
                    <h3 className="font-medium">Carbon Saved</h3>
                  </div>
                  <div className="text-2xl font-bold text-green-700">
                    {Math.abs(calculateCarbonSavings()).toLocaleString()} kg
                  </div>
                  <p className="text-sm text-green-600">CO₂ offset this year</p>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="h-5 w-5 text-blue-600" />
                    <h3 className="font-medium">Offset Ratio</h3>
                  </div>
                  <div className="text-2xl font-bold text-blue-700">
                    {getOffsetPercentage().toFixed(0)}%
                  </div>
                  <p className="text-sm text-blue-600">Carbon neutrality achieved</p>
                </CardContent>
              </Card>

              <Card className="border-purple-200 bg-purple-50 dark:bg-purple-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Award className="h-5 w-5 text-purple-600" />
                    <h3 className="font-medium">Eco-Badges</h3>
                  </div>
                  <div className="text-2xl font-bold text-purple-700">
                    {ecoBadges.filter(badge => badge.earned).length}
                  </div>
                  <p className="text-sm text-purple-600">Sustainability achievements</p>
                </CardContent>
              </Card>
            </div>

            {/* Annual Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">2024 Sustainability Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Carbon Neutral Goal (100%)</span>
                    <span className="font-medium">{getOffsetPercentage().toFixed(1)}%</span>
                  </div>
                  <Progress value={Math.min(getOffsetPercentage(), 100)} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Total Emissions:</span>
                    <p className="font-medium">{totalEmissions.toLocaleString()} kg CO₂</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Total Offsets:</span>
                    <p className="font-medium text-green-600">{totalOffset.toLocaleString()} kg CO₂</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="flex gap-2">
              <Button onClick={generateReport} className="flex-1">
                <Download className="h-4 w-4 mr-2" />
                Download Report
              </Button>
              <Button variant="outline" className="flex-1">
                <Leaf className="h-4 w-4 mr-2" />
                Purchase Offsets
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="details" className="space-y-4">
            {carbonData.map((data, index) => (
              <motion.div
                key={data.eventId}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{data.eventName}</CardTitle>
                        <CardDescription className="flex items-center gap-4 mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {data.eventDate.toLocaleDateString()}
                          </span>
                        </CardDescription>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={data.netImpact <= 0 ? 'text-green-600 bg-green-100' : 'text-red-600 bg-red-100'}
                      >
                        {data.netImpact <= 0 ? 'Carbon Positive' : 'Carbon Neutral Needed'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Emissions Breakdown */}
                    <div>
                      <h4 className="font-medium mb-3">Carbon Footprint Breakdown</h4>
                      <div className="space-y-2">
                        {Object.entries(data.breakdown).map(([category, amount]) => (
                          <div key={category} className="flex items-center justify-between">
                            <span className="text-sm capitalize">{category}</span>
                            <span className="font-medium">{amount} kg CO₂</span>
                          </div>
                        ))}
                        <div className="border-t pt-2 flex justify-between font-bold">
                          <span>Total Emissions</span>
                          <span>{data.totalEmissions} kg CO₂</span>
                        </div>
                      </div>
                    </div>

                    {/* Offset Information */}
                    <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-green-800 dark:text-green-400">Carbon Offsets</h4>
                        <span className="font-bold text-green-700 dark:text-green-300">
                          {data.offsetCredits} kg CO₂
                        </span>
                      </div>
                      <div className="space-y-1">
                        {data.offsetMethods.map((method, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-sm text-green-700 dark:text-green-300">
                            <Leaf className="h-3 w-3" />
                            {method}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Net Impact */}
                    <div className={`p-4 rounded-lg ${
                      data.netImpact <= 0 
                        ? 'bg-green-50 dark:bg-green-900/20' 
                        : 'bg-yellow-50 dark:bg-yellow-900/20'
                    }`}>
                      <h4 className={`font-medium mb-1 ${
                        data.netImpact <= 0 ? 'text-green-800 dark:text-green-400' : 'text-yellow-800 dark:text-yellow-400'
                      }`}>
                        Net Environmental Impact
                      </h4>
                      <p className={`text-sm ${
                        data.netImpact <= 0 ? 'text-green-700 dark:text-green-300' : 'text-yellow-700 dark:text-yellow-300'
                      }`}>
                        {data.netImpact <= 0 
                          ? `You removed ${Math.abs(data.netImpact)} kg CO₂ from the atmosphere!`
                          : `${data.netImpact} kg CO₂ needs additional offsetting`
                        }
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </TabsContent>

          <TabsContent value="badges" className="space-y-4">
            <div className="grid gap-4">
              {ecoBadges.map((badge, index) => (
                <motion.div
                  key={badge.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={`border-l-4 ${
                    badge.earned 
                      ? 'border-l-green-500 bg-green-50 dark:bg-green-900/20' 
                      : 'border-l-gray-300 opacity-75'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`text-3xl ${badge.earned ? '' : 'grayscale opacity-50'}`}>
                            {badge.icon}
                          </div>
                          <div>
                            <h4 className="font-medium">{badge.name}</h4>
                            <p className="text-sm text-muted-foreground mb-2">{badge.description}</p>
                            <p className="text-xs text-muted-foreground">
                              <strong>Criteria:</strong> {badge.criteria}
                            </p>
                            {badge.earned && badge.earnedDate && (
                              <p className="text-xs text-green-600 mt-1">
                                Earned on {badge.earnedDate.toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={`${getBadgeLevelColor(badge.level)} border`}>
                            {badge.level.toUpperCase()}
                          </Badge>
                          {badge.earned && (
                            <div className="mt-2">
                              <Award className="h-5 w-5 text-green-600 mx-auto" />
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}