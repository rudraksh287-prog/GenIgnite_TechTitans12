import { useState } from 'react';
import { ArrowLeft, Building, Globe, MapPin, Moon, Sun, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { User } from '../App';

interface SponsorSignupProps {
  onSignupComplete: (user: User) => void;
  onBack: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export default function SponsorSignup({ onSignupComplete, onBack, isDarkMode, toggleDarkMode }: SponsorSignupProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    companyName: '',
    website: '',
    phone: '',
    description: '',
    eventTypes: [] as string[],
    locations: [] as string[]
  });

  const eventTypes = [
    'Corporate Events',
    'Sports Events',
    'Concerts & Music',
    'Conferences',
    'Trade Shows',
    'Community Events',
    'Charity Events',
    'Tech Events'
  ];

  const locationOptions = [
    'New York, NY',
    'Los Angeles, CA',
    'Chicago, IL',
    'Houston, TX',
    'Phoenix, AZ',
    'Philadelphia, PA',
    'San Antonio, TX',
    'San Diego, CA'
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCheckboxChange = (field: 'eventTypes' | 'locations', value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 1) {
      if (!formData.name || !formData.email || !formData.password || !formData.companyName) {
        toast.error('Please fill in all required fields');
        return;
      }
      setStep(2);
    } else {
      if (formData.eventTypes.length === 0 || formData.locations.length === 0) {
        toast.error('Please select at least one event type and location');
        return;
      }
      
      const user: User = {
        id: Math.random().toString(36).substr(2, 9),
        role: 'sponsor' as const,
        name: formData.name,
        email: formData.email,
        companyName: formData.companyName,
        website: formData.website,
        phone: formData.phone,
        description: formData.description,
        eventTypes: formData.eventTypes,
        locations: formData.locations
      };
      
      toast.success('Sponsor account created successfully!');
      onSignupComplete(user);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white dark:from-blue-900 dark:to-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5 dark:opacity-10"></div>
      <motion.div
        className="absolute top-20 left-20 w-32 h-32 bg-blue-200/20 dark:bg-blue-800/20 rounded-full blur-3xl"
        animate={{ x: [0, 50, 0], y: [0, -30, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-20 right-20 w-48 h-48 bg-purple-200/20 dark:bg-purple-800/20 rounded-full blur-3xl"
        animate={{ x: [0, -40, 0], y: [0, 20, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Header */}
      <motion.header 
        className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-gray-200/50 dark:border-gray-700/50"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Sparkles className="h-6 w-6 text-blue-600" />
            <div>
              <h1 className="text-lg bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent">
                P.E.O.N
              </h1>
              <p className="text-xs text-muted-foreground -mt-1">Platform for Event, Organizers and Networking</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleDarkMode}
            className="p-2 rounded-full"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4 text-yellow-500" />
            ) : (
              <Moon className="h-4 w-4 text-slate-600" />
            )}
          </Button>
        </div>
      </motion.header>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-2xl relative z-10 mt-20"
      >
        <Card className="backdrop-blur-md bg-white/90 dark:bg-slate-800/90 border border-white/20 dark:border-slate-700/50 shadow-2xl">
        <CardHeader>
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={step === 1 ? onBack : () => setStep(1)}
              className="p-2"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5 text-blue-600" />
                Sponsor Registration
              </CardTitle>
              <CardDescription>
                {step === 1 ? 'Create your sponsor account' : 'Tell us about your preferences'}
              </CardDescription>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <div className={`h-2 rounded-full flex-1 ${step >= 1 ? 'bg-blue-600' : 'bg-gray-200'}`} />
            <div className={`h-2 rounded-full flex-1 ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`} />
          </div>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            {step === 1 ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="john@company.com"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    placeholder="Create a secure password"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company Name *</Label>
                    <Input
                      id="companyName"
                      value={formData.companyName}
                      onChange={(e) => handleInputChange('companyName', e.target.value)}
                      placeholder="Company Inc."
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="website">Company Website</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="website"
                      value={formData.website}
                      onChange={(e) => handleInputChange('website', e.target.value)}
                      placeholder="https://company.com"
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Company Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Briefly describe your company and sponsorship goals..."
                    rows={3}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="space-y-4">
                  <Label>Event Types You're Interested In *</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {eventTypes.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <Checkbox
                          id={type}
                          checked={formData.eventTypes.includes(type)}
                          onCheckedChange={() => handleCheckboxChange('eventTypes', type)}
                        />
                        <Label htmlFor={type} className="text-sm">{type}</Label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <Label className="flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Locations You Can Sponsor *
                  </Label>
                  <div className="grid grid-cols-2 gap-3">
                    {locationOptions.map((location) => (
                      <div key={location} className="flex items-center space-x-2">
                        <Checkbox
                          id={location}
                          checked={formData.locations.includes(location)}
                          onCheckedChange={() => handleCheckboxChange('locations', location)}
                        />
                        <Label htmlFor={location} className="text-sm">{location}</Label>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
            
            <Button type="submit" className="w-full">
              {step === 1 ? 'Continue' : 'Create Sponsor Account'}
            </Button>
          </CardContent>
        </form>
      </Card>
      </motion.div>
    </div>
  );
}