import { useState } from 'react';
import { LogOut, Plus, Calendar, Users, Star, Edit, MapPin, Clock, DollarSign, Moon, Sun, Sparkles, Bell } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { User } from '../App';
import NotificationSystem from './NotificationSystem';
import WalletComponent from './WalletComponent';
import ContractManager from './ContractManager';
import AchievementBadges from './AchievementBadges';
import SelectedCandidatesPortfolio from './SelectedCandidatesPortfolio';
import RedirectGateway from './RedirectGateway';

interface OrganizerDashboardProps {
  user: User;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export default function OrganizerDashboard({ user, onLogout, isDarkMode, toggleDarkMode }: OrganizerDashboardProps) {
  const [events, setEvents] = useState([
    {
      id: '1',
      title: 'Annual Tech Conference 2024',
      type: 'Tech Events',
      date: '2024-06-15',
      location: 'New York, NY',
      description: 'A comprehensive tech conference featuring industry leaders.',
      expectedAttendees: 500,
      needsSponsors: true,
      needsVolunteers: true,
      status: 'Planning',
      budget: '$50,000',
      sponsorsNeeded: 5,
      volunteersNeeded: 15
    }
  ]);

  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: '',
    type: '',
    date: '',
    location: '',
    description: '',
    expectedAttendees: '',
    budget: '',
    needsSponsors: false,
    needsVolunteers: false,
    sponsorsNeeded: '',
    volunteersNeeded: ''
  });

  const eventTypes = [
    'Corporate Events',
    'Conferences & Seminars',
    'Trade Shows & Exhibitions',
    'Sports Events',
    'Concerts & Entertainment',
    'Community Events',
    'Charity & Fundraising',
    'Tech Events'
  ];

  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.type || !newEvent.date || !newEvent.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    const event = {
      id: Math.random().toString(36).substr(2, 9),
      ...newEvent,
      expectedAttendees: parseInt(newEvent.expectedAttendees) || 0,
      sponsorsNeeded: parseInt(newEvent.sponsorsNeeded) || 0,
      volunteersNeeded: parseInt(newEvent.volunteersNeeded) || 0,
      status: 'Planning'
    };

    setEvents(prev => [...prev, event]);
    setNewEvent({
      title: '',
      type: '',
      date: '',
      location: '',
      description: '',
      expectedAttendees: '',
      budget: '',
      needsSponsors: false,
      needsVolunteers: false,
      sponsorsNeeded: '',
      volunteersNeeded: ''
    });
    setIsCreateEventOpen(false);
    toast.success('Event created successfully!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Planning': return 'bg-yellow-100 text-yellow-800';
      case 'Active': return 'bg-green-100 text-green-800';
      case 'Completed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-gray-200/50 dark:border-gray-700/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <Sparkles className="h-6 w-6 text-green-600" />
                <div>
                  <h1 className="text-lg bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                    P.E.O.N
                  </h1>
                  <p className="text-xs text-muted-foreground -mt-1">Platform for Event, Organizers and Networking</p>
                </div>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Organizer
              </Badge>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Welcome, {user.name}</span>
              <NotificationSystem userRole="organizer" isDarkMode={isDarkMode} />
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDarkMode}
                className="p-2 rounded-full"
              >
                {isDarkMode ? (
                  <Sun className="h-4 w-4 text-yellow-500" />
                ) : (
                  <Moon className="h-4 w-4 text-slate-600" />
                )}
              </Button>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="events" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="events">My Events</TabsTrigger>
            <TabsTrigger value="candidates">Candidates</TabsTrigger>
            <TabsTrigger value="wallet">Wallet</TabsTrigger>
            <TabsTrigger value="contracts">Contracts</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="events" className="space-y-6">
            {/* Create Event Button */}
            <div className="flex justify-between items-center">
              <h2>Your Events</h2>
              <Dialog open={isCreateEventOpen} onOpenChange={setIsCreateEventOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create New Event
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Create New Event</DialogTitle>
                    <DialogDescription>
                      Fill in the details for your new event
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="title">Event Title *</Label>
                        <Input
                          id="title"
                          value={newEvent.title}
                          onChange={(e) => setNewEvent(prev => ({ ...prev, title: e.target.value }))}
                          placeholder="Annual Tech Conference"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Event Type *</Label>
                        <Select onValueChange={(value) => setNewEvent(prev => ({ ...prev, type: value }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            {eventTypes.map((type) => (
                              <SelectItem key={type} value={type}>{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="date">Date *</Label>
                        <Input
                          id="date"
                          type="date"
                          value={newEvent.date}
                          onChange={(e) => setNewEvent(prev => ({ ...prev, date: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="location">Location *</Label>
                        <Input
                          id="location"
                          value={newEvent.location}
                          onChange={(e) => setNewEvent(prev => ({ ...prev, location: e.target.value }))}
                          placeholder="New York, NY"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newEvent.description}
                        onChange={(e) => setNewEvent(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Describe your event..."
                        rows={3}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="attendees">Expected Attendees</Label>
                        <Input
                          id="attendees"
                          type="number"
                          value={newEvent.expectedAttendees}
                          onChange={(e) => setNewEvent(prev => ({ ...prev, expectedAttendees: e.target.value }))}
                          placeholder="500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="budget">Budget</Label>
                        <Input
                          id="budget"
                          value={newEvent.budget}
                          onChange={(e) => setNewEvent(prev => ({ ...prev, budget: e.target.value }))}
                          placeholder="$50,000"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="needsSponsors"
                          checked={newEvent.needsSponsors}
                          onCheckedChange={(checked) => setNewEvent(prev => ({ ...prev, needsSponsors: checked }))}
                        />
                        <Label htmlFor="needsSponsors">Looking for sponsors</Label>
                      </div>
                      
                      {newEvent.needsSponsors && (
                        <div className="space-y-2 ml-6">
                          <Label htmlFor="sponsorsNeeded">Number of sponsors needed</Label>
                          <Input
                            id="sponsorsNeeded"
                            type="number"
                            value={newEvent.sponsorsNeeded}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, sponsorsNeeded: e.target.value }))}
                            placeholder="5"
                            className="w-32"
                          />
                        </div>
                      )}
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="needsVolunteers"
                          checked={newEvent.needsVolunteers}
                          onCheckedChange={(checked) => setNewEvent(prev => ({ ...prev, needsVolunteers: checked }))}
                        />
                        <Label htmlFor="needsVolunteers">Looking for volunteers</Label>
                      </div>
                      
                      {newEvent.needsVolunteers && (
                        <div className="space-y-2 ml-6">
                          <Label htmlFor="volunteersNeeded">Number of volunteers needed</Label>
                          <Input
                            id="volunteersNeeded"
                            type="number"
                            value={newEvent.volunteersNeeded}
                            onChange={(e) => setNewEvent(prev => ({ ...prev, volunteersNeeded: e.target.value }))}
                            placeholder="15"
                            className="w-32"
                          />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 pt-4">
                      <Button onClick={handleCreateEvent}>Create Event</Button>
                      <Button variant="outline" onClick={() => setIsCreateEventOpen(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Events List */}
            {events.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="mb-2">No events yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Create your first event to get started
                  </p>
                  <Button onClick={() => setIsCreateEventOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Event
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6">
                {events.map((event) => (
                  <Card key={event.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-xl">{event.title}</CardTitle>
                          <CardDescription className="flex items-center gap-4 mt-2">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              {new Date(event.date).toLocaleDateString()}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {event.location}
                            </span>
                          </CardDescription>
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getStatusColor(event.status)}>
                            {event.status}
                          </Badge>
                          <Badge variant="outline">{event.type}</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-muted-foreground">{event.description}</p>
                      
                      <div className="grid md:grid-cols-4 gap-4">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{event.expectedAttendees} attendees</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{event.budget}</span>
                        </div>
                        {event.needsSponsors && (
                          <div className="flex items-center gap-2">
                            <Star className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{event.sponsorsNeeded} sponsors needed</span>
                          </div>
                        )}
                        {event.needsVolunteers && (
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{event.volunteersNeeded} volunteers needed</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Event
                        </Button>
                        <Button variant="outline" size="sm">
                          View Applications
                        </Button>
                        <Button variant="outline" size="sm">
                          Event Dashboard
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="candidates" className="space-y-6">
            <SelectedCandidatesPortfolio 
              eventId="1"
              eventName="Annual Tech Conference 2024"
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="wallet" className="space-y-6">
            <WalletComponent userRole="organizer" isDarkMode={isDarkMode} />
            <RedirectGateway 
              eventContext={{
                eventName: "Annual Tech Conference 2024",
                organizerName: user.name,
                eventDate: "2024-06-15"
              }}
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="contracts" className="space-y-6">
            <ContractManager 
              userRole="organizer" 
              userName={user.name}
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <AchievementBadges 
              userRole="organizer" 
              userStats={{
                eventsParticipated: 3,
                eventsOrganized: 3,
                satisfactionRating: 4.8
              }}
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Organizer Profile
                  </CardTitle>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="bg-green-100 text-green-600 text-lg">
                      {user.organizationName?.charAt(0) || user.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3>{user.organizationName}</h3>
                    <p className="text-muted-foreground">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="mb-2">Contact Information</h4>
                      <div className="space-y-2 text-sm">
                        <p><span className="font-medium">Phone:</span> {user.phone || 'Not provided'}</p>
                        <p><span className="font-medium">Website:</span> {user.website || 'Not provided'}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-2">Organization Description</h4>
                      <p className="text-sm text-muted-foreground">
                        {user.description || 'No description provided'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="mb-2">Event Types</h4>
                      <div className="flex flex-wrap gap-1">
                        {user.eventTypes?.map((type: string, index: number) => (
                          <Badge key={index} variant="secondary">{type}</Badge>
                        )) || <p className="text-sm text-muted-foreground">No event types set</p>}
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-2">Experience</h4>
                      <p className="text-sm text-muted-foreground">
                        {user.experience || 'No experience listed'}
                      </p>
                    </div>

                    {user.previousEvents && (
                      <div>
                        <h4 className="mb-2">Previous Events</h4>
                        <p className="text-sm text-muted-foreground">{user.previousEvents}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Analytics */}
            <Card>
              <CardHeader>
                <CardTitle>Event Analytics</CardTitle>
                <CardDescription>Overview of your event management activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <h3 className="text-2xl text-green-600">{events.length}</h3>
                    <p className="text-sm text-muted-foreground">Total Events</p>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <h3 className="text-2xl text-blue-600">
                      {events.reduce((sum, event) => sum + event.expectedAttendees, 0)}
                    </h3>
                    <p className="text-sm text-muted-foreground">Total Attendees</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <h3 className="text-2xl text-purple-600">
                      {events.filter(event => event.status === 'Planning').length}
                    </h3>
                    <p className="text-sm text-muted-foreground">Upcoming Events</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}