import { useState, useEffect } from 'react';
import { Trophy, Star, Zap, Target, Gift, Crown, Medal, Award, TrendingUp, Users } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface UserLevel {
  level: number;
  title: string;
  pointsRequired: number;
  pointsToNext: number;
  benefits: string[];
  icon: string;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  points: number;
  unlocked: boolean;
  progress?: number;
  maxProgress?: number;
  unlockedDate?: Date;
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  reward: number;
  deadline: Date;
  progress: number;
  maxProgress: number;
  type: 'daily' | 'weekly' | 'monthly' | 'special';
  completed: boolean;
}

interface GameificationSystemProps {
  currentPoints?: number;
  isDarkMode?: boolean;
}

export default function GameificationSystem({ 
  currentPoints = 1250, 
  isDarkMode 
}: GameificationSystemProps) {
  const [userLevel, setUserLevel] = useState<UserLevel | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);

  // Define level system
  const levels: UserLevel[] = [
    {
      level: 1,
      title: 'Newcomer',
      pointsRequired: 0,
      pointsToNext: 500,
      benefits: ['Basic profile', 'Event applications'],
      icon: '🌱'
    },
    {
      level: 2,
      title: 'Helper',
      pointsRequired: 500,
      pointsToNext: 1000,
      benefits: ['Priority support', 'Event recommendations'],
      icon: '🤝'
    },
    {
      level: 3,
      title: 'Contributor',
      pointsRequired: 1000,
      pointsToNext: 2000,
      benefits: ['Featured profile', 'Early event access'],
      icon: '⭐'
    },
    {
      level: 4,
      title: 'Champion',
      pointsRequired: 2000,
      pointsToNext: 4000,
      benefits: ['Leadership opportunities', 'Bonus rewards'],
      icon: '🏆'
    },
    {
      level: 5,
      title: 'Legend',
      pointsRequired: 4000,
      pointsToNext: 0,
      benefits: ['VIP status', 'Mentor privileges', 'Exclusive events'],
      icon: '👑'
    }
  ];

  // Calculate current level
  useEffect(() => {
    const level = levels
      .slice()
      .reverse()
      .find(l => currentPoints >= l.pointsRequired) || levels[0];
    setUserLevel(level);
  }, [currentPoints]);

  // Mock achievements
  useEffect(() => {
    const mockAchievements: Achievement[] = [
      {
        id: '1',
        title: 'First Steps',
        description: 'Complete your first volunteer task',
        icon: '👶',
        rarity: 'common',
        points: 50,
        unlocked: true,
        unlockedDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      },
      {
        id: '2',
        title: 'Team Player',
        description: 'Volunteer for 5 different events',
        icon: '🤝',
        rarity: 'common',
        points: 100,
        unlocked: true,
        progress: 5,
        maxProgress: 5,
        unlockedDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
      },
      {
        id: '3',
        title: 'Tech Wizard',
        description: 'Complete 10 tech-related volunteer tasks',
        icon: '🧙‍♂️',
        rarity: 'rare',
        points: 200,
        unlocked: true,
        progress: 10,
        maxProgress: 10,
        unlockedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      },
      {
        id: '4',
        title: 'Community Champion',
        description: 'Volunteer for 20 community events',
        icon: '🏆',
        rarity: 'epic',
        points: 500,
        unlocked: false,
        progress: 12,
        maxProgress: 20
      },
      {
        id: '5',
        title: 'Legend of Volunteering',
        description: 'Reach 5000 volunteer points',
        icon: '👑',
        rarity: 'legendary',
        points: 1000,
        unlocked: false,
        progress: currentPoints,
        maxProgress: 5000
      },
      {
        id: '6',
        title: 'Marathon Master',
        description: 'Volunteer for events lasting 8+ hours',
        icon: '⚡',
        rarity: 'rare',
        points: 300,
        unlocked: false,
        progress: 2,
        maxProgress: 3
      }
    ];
    setAchievements(mockAchievements);
  }, [currentPoints]);

  // Mock challenges
  useEffect(() => {
    const mockChallenges: Challenge[] = [
      {
        id: '1',
        title: 'Daily Helper',
        description: 'Apply to 1 event today',
        reward: 25,
        deadline: new Date(Date.now() + 24 * 60 * 60 * 1000),
        progress: 0,
        maxProgress: 1,
        type: 'daily',
        completed: false
      },
      {
        id: '2',
        title: 'Weekend Warrior',
        description: 'Complete 2 volunteer tasks this weekend',
        reward: 100,
        deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        progress: 1,
        maxProgress: 2,
        type: 'weekly',
        completed: false
      },
      {
        id: '3',
        title: 'Social Butterfly',
        description: 'Connect with 5 other volunteers this month',
        reward: 200,
        deadline: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
        progress: 3,
        maxProgress: 5,
        type: 'monthly',
        completed: false
      },
      {
        id: '4',
        title: 'Earth Day Special',
        description: 'Volunteer for an environmental event',
        reward: 150,
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        progress: 0,
        maxProgress: 1,
        type: 'special',
        completed: false
      }
    ];
    setChallenges(mockChallenges);
  }, []);

  // Mock leaderboard
  useEffect(() => {
    const mockLeaderboard = [
      { rank: 1, name: 'Alex Rodriguez', points: 4250, level: 'Champion', badge: '👑' },
      { rank: 2, name: 'Sarah Johnson', points: 3800, level: 'Champion', badge: '🏆' },
      { rank: 3, name: 'Mike Chen', points: 3200, level: 'Champion', badge: '🥉' },
      { rank: 4, name: 'You', points: currentPoints, level: userLevel?.title || 'Helper', badge: '⭐' },
      { rank: 5, name: 'Emily Davis', points: 1100, level: 'Contributor', badge: '🌟' }
    ];
    setLeaderboard(mockLeaderboard);
  }, [currentPoints, userLevel]);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-gray-600 bg-gray-100';
      case 'rare': return 'text-blue-600 bg-blue-100';
      case 'epic': return 'text-purple-600 bg-purple-100';
      case 'legendary': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getChallengeTypeColor = (type: string) => {
    switch (type) {
      case 'daily': return 'text-green-600 bg-green-100';
      case 'weekly': return 'text-blue-600 bg-blue-100';
      case 'monthly': return 'text-purple-600 bg-purple-100';
      case 'special': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const calculateLevelProgress = () => {
    if (!userLevel) return 0;
    const currentLevelPoints = currentPoints - userLevel.pointsRequired;
    const nextLevelGap = userLevel.pointsToNext;
    return nextLevelGap > 0 ? (currentLevelPoints / nextLevelGap) * 100 : 100;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-600" />
          Volunteer Achievements
        </CardTitle>
        <CardDescription>
          Level up your volunteer journey and earn rewards
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="level" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="level">Level</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="challenges">Challenges</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          </TabsList>

          <TabsContent value="level" className="space-y-6">
            {userLevel && (
              <div className="space-y-4">
                {/* Current Level Display */}
                <div className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg p-6 text-white">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="text-4xl">{userLevel.icon}</div>
                      <div>
                        <h3 className="text-xl font-bold">Level {userLevel.level}</h3>
                        <p className="text-yellow-100">{userLevel.title}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold">{currentPoints.toLocaleString()}</div>
                      <p className="text-yellow-100 text-sm">Points</p>
                    </div>
                  </div>
                  
                  {userLevel.pointsToNext > 0 && (
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress to next level</span>
                        <span>{userLevel.pointsToNext - (currentPoints - userLevel.pointsRequired)} points to go</span>
                      </div>
                      <Progress 
                        value={calculateLevelProgress()} 
                        className="h-2 bg-yellow-300"
                      />
                    </div>
                  )}
                </div>

                {/* Level Benefits */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Current Benefits</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {userLevel.benefits.map((benefit, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Points Breakdown */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Points Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Events Completed</span>
                        <span className="font-medium">800 pts</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Achievements Unlocked</span>
                        <span className="font-medium">350 pts</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Challenge Rewards</span>
                        <span className="font-medium">100 pts</span>
                      </div>
                      <div className="border-t pt-2 flex justify-between font-bold">
                        <span>Total Points</span>
                        <span>{currentPoints.toLocaleString()} pts</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="achievements" className="space-y-4">
            <div className="grid gap-4">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={`border-l-4 ${
                    achievement.unlocked 
                      ? 'border-l-green-500 bg-green-50 dark:bg-green-900/20' 
                      : 'border-l-gray-300'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`text-2xl ${achievement.unlocked ? '' : 'grayscale opacity-50'}`}>
                            {achievement.icon}
                          </div>
                          <div>
                            <h4 className="font-medium">{achievement.title}</h4>
                            <p className="text-sm text-muted-foreground">{achievement.description}</p>
                            {achievement.progress !== undefined && achievement.maxProgress && (
                              <div className="mt-2">
                                <Progress 
                                  value={(achievement.progress / achievement.maxProgress) * 100} 
                                  className="h-2 w-32"
                                />
                                <p className="text-xs text-muted-foreground mt-1">
                                  {achievement.progress}/{achievement.maxProgress}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={getRarityColor(achievement.rarity)}>
                            {achievement.rarity}
                          </Badge>
                          <p className="text-sm font-medium mt-1">+{achievement.points} pts</p>
                          {achievement.unlocked && achievement.unlockedDate && (
                            <p className="text-xs text-muted-foreground">
                              Unlocked {achievement.unlockedDate.toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="challenges" className="space-y-4">
            <div className="grid gap-4">
              {challenges.map((challenge, index) => (
                <motion.div
                  key={challenge.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-medium">{challenge.title}</h4>
                            <Badge className={getChallengeTypeColor(challenge.type)}>
                              {challenge.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{challenge.description}</p>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Progress</span>
                              <span>{challenge.progress}/{challenge.maxProgress}</span>
                            </div>
                            <Progress 
                              value={(challenge.progress / challenge.maxProgress) * 100} 
                              className="h-2"
                            />
                          </div>
                          
                          <p className="text-xs text-muted-foreground mt-2">
                            Deadline: {challenge.deadline.toLocaleDateString()}
                          </p>
                        </div>
                        
                        <div className="text-right ml-4">
                          <div className="bg-yellow-100 dark:bg-yellow-900/20 rounded-lg p-2">
                            <Gift className="h-5 w-5 text-yellow-600 mx-auto mb-1" />
                            <p className="text-sm font-medium">+{challenge.reward}</p>
                            <p className="text-xs text-muted-foreground">points</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="h-5 w-5 text-yellow-600" />
                  Top Volunteers This Month
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {leaderboard.map((user, index) => (
                    <motion.div
                      key={user.rank}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`flex items-center justify-between p-3 rounded-lg ${
                        user.name === 'You' 
                          ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800' 
                          : 'bg-gray-50 dark:bg-gray-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700">
                          <span className="font-bold text-sm">#{user.rank}</span>
                        </div>
                        <div className="text-2xl">{user.badge}</div>
                        <div>
                          <p className={`font-medium ${user.name === 'You' ? 'text-blue-700 dark:text-blue-400' : ''}`}>
                            {user.name}
                          </p>
                          <p className="text-sm text-muted-foreground">{user.level}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{user.points.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">points</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <div className="text-center">
              <Button variant="outline">
                <TrendingUp className="h-4 w-4 mr-2" />
                View Full Leaderboard
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}