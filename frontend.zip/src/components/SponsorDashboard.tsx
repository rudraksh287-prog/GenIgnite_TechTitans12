import { useState } from 'react';
import { LogOut, Search, Filter, MapPin, Calendar, Users, Star, Building, Edit, Moon, Sun, Sparkles, Bell, Brain, Leaf } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User } from '../App';
import NotificationSystem from './NotificationSystem';
import WalletComponent from './WalletComponent';
import AIRecommendationSystem from './AIRecommendationSystem';
import ContractManager from './ContractManager';
import AchievementBadges from './AchievementBadges';
import CarbonFootprintTracker from './CarbonFootprintTracker';
import RedirectGateway from './RedirectGateway';

interface SponsorDashboardProps {
  user: User;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export default function SponsorDashboard({ user, onLogout, isDarkMode, toggleDarkMode }: SponsorDashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');

  // Mock events data
  const events = [
    {
      id: '1',
      title: 'Tech Innovation Summit 2024',
      type: 'Tech Events',
      date: '2024-03-15',
      location: 'New York, NY',
      organizer: 'TechCorp Events',
      description: 'A premier gathering of tech innovators and industry leaders.',
      attendees: 500,
      sponsorshipTiers: ['Gold ($10k)', 'Silver ($5k)', 'Bronze ($2k)'],
      needsSponsors: true
    },
    {
      id: '2',
      title: 'Corporate Leadership Conference',
      type: 'Corporate Events',
      date: '2024-04-22',
      location: 'Los Angeles, CA',
      organizer: 'Business Leaders Inc',
      description: 'Annual conference for corporate executives and managers.',
      attendees: 300,
      sponsorshipTiers: ['Platinum ($15k)', 'Gold ($8k)', 'Silver ($4k)'],
      needsSponsors: true
    },
    {
      id: '3',
      title: 'Charity Gala for Education',
      type: 'Charity Events',
      date: '2024-05-10',
      location: 'Chicago, IL',
      organizer: 'Education First Foundation',
      description: 'Fundraising gala to support education initiatives.',
      attendees: 200,
      sponsorshipTiers: ['Title Sponsor ($20k)', 'Supporting ($5k)'],
      needsSponsors: true
    }
  ];

  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      {/* Header */}
      <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-gray-200/50 dark:border-gray-700/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <Sparkles className="h-6 w-6 text-blue-600" />
                <div>
                  <h1 className="text-lg bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent">
                    P.E.O.N
                  </h1>
                  <p className="text-xs text-muted-foreground -mt-1">Platform for Event, Organizers and Networking</p>
                </div>
              </div>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                Sponsor
              </Badge>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Welcome, {user.name}</span>
              <NotificationSystem userRole="sponsor" isDarkMode={isDarkMode} />
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDarkMode}
                className="p-2 rounded-full"
              >
                {isDarkMode ? (
                  <Sun className="h-4 w-4 text-yellow-500" />
                ) : (
                  <Moon className="h-4 w-4 text-slate-600" />
                )}
              </Button>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="explore" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="explore">Explore Events</TabsTrigger>
            <TabsTrigger value="wallet">Wallet</TabsTrigger>
            <TabsTrigger value="carbon">Carbon Impact</TabsTrigger>
            <TabsTrigger value="contracts">Contracts</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="explore" className="space-y-6">
            {/* AI Recommendations */}
            <AIRecommendationSystem 
              userRole="sponsor"
              userInterests={user.eventTypes}
              userLocation={user.locations?.[0]}
              isDarkMode={isDarkMode}
            />

            {/* Search and Filter */}
            <Card>
              <CardContent className="p-6">
                <div className="flex gap-4 items-center">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search events by name, type, or location..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline">
                    <Brain className="h-4 w-4 mr-2" />
                    AI Suggestions
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Events Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEvents.map((event) => (
                <Card key={event.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{event.title}</CardTitle>
                        <CardDescription>{event.organizer}</CardDescription>
                      </div>
                      <Badge variant="secondary">{event.type}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{event.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {new Date(event.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        {event.location}
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        {event.attendees} expected attendees
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-sm font-medium">Sponsorship Opportunities:</p>
                      <div className="flex flex-wrap gap-1">
                        {event.sponsorshipTiers.map((tier, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tier}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full">
                      Express Interest
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredEvents.length === 0 && (
              <Card>
                <CardContent className="p-12 text-center">
                  <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="mb-2">No events found</h3>
                  <p className="text-muted-foreground">
                    Try adjusting your search criteria or check back later for new events.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="wallet" className="space-y-6">
            <WalletComponent userRole="sponsor" isDarkMode={isDarkMode} />
            <RedirectGateway 
              eventContext={{
                eventName: "Tech Innovation Summit 2024",
                organizerName: "TechCorp Events",
                eventDate: "2024-03-15"
              }}
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="carbon" className="space-y-6">
            <CarbonFootprintTracker isDarkMode={isDarkMode} />
          </TabsContent>

          <TabsContent value="contracts" className="space-y-6">
            <ContractManager 
              userRole="sponsor" 
              userName={user.name}
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <AchievementBadges 
              userRole="sponsor" 
              userStats={{
                eventsParticipated: 5,
                totalSpent: 25000,
                satisfactionRating: 4.9
              }}
              isDarkMode={isDarkMode}
            />
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Building className="h-5 w-5" />
                    Sponsor Profile
                  </CardTitle>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="bg-blue-100 text-blue-600 text-lg">
                      {user.companyName?.charAt(0) || user.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3>{user.companyName}</h3>
                    <p className="text-muted-foreground">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="mb-2">Contact Information</h4>
                      <div className="space-y-2 text-sm">
                        <p><span className="font-medium">Phone:</span> {user.phone || 'Not provided'}</p>
                        <p><span className="font-medium">Website:</span> {user.website || 'Not provided'}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-2">Company Description</h4>
                      <p className="text-sm text-muted-foreground">
                        {user.description || 'No description provided'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="mb-2">Event Interests</h4>
                      <div className="flex flex-wrap gap-1">
                        {user.eventTypes?.map((type: string, index: number) => (
                          <Badge key={index} variant="secondary">{type}</Badge>
                        )) || <p className="text-sm text-muted-foreground">No preferences set</p>}
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-2">Preferred Locations</h4>
                      <div className="flex flex-wrap gap-1">
                        {user.locations?.map((location: string, index: number) => (
                          <Badge key={index} variant="outline">{location}</Badge>
                        )) || <p className="text-sm text-muted-foreground">No locations set</p>}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sponsorship History */}
            <Card>
              <CardHeader>
                <CardTitle>Sponsorship History</CardTitle>
                <CardDescription>Your past and current sponsorships</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Star className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="mb-2">No sponsorships yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start exploring events to begin your sponsorship journey.
                  </p>
                  <Button onClick={() => document.querySelector('[value="explore"]')?.click()}>
                    Browse Events
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}