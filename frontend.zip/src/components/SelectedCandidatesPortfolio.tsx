import { useState, useEffect } from 'react';
import { Users, Star, MapPin, Calendar, Award, Eye, MessageSquare, CheckCircle, FileText, Download } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { toast } from 'sonner';

interface SelectedVolunteer {
  id: string;
  name: string;
  email: string;
  location: string;
  rating: number;
  totalEvents: number;
  selectedDate: Date;
  eventName: string;
  role: string;
  status: 'selected' | 'contacted' | 'confirmed' | 'declined';
  portfolio: {
    bio: string;
    skills: string[];
    languages: string[];
    interests: string[];
    experience: string;
    achievements: string[];
    previousEvents: {
      name: string;
      role: string;
      date: string;
      rating: number;
    }[];
  };
  contractSigned: boolean;
  paymentAmount?: number;
}

interface SelectedCandidatesPortfolioProps {
  eventId?: string;
  eventName?: string;
  isDarkMode?: boolean;
}

export default function SelectedCandidatesPortfolio({ 
  eventId = '1', 
  eventName = 'Annual Tech Conference 2024',
  isDarkMode 
}: SelectedCandidatesPortfolioProps) {
  const [selectedVolunteers, setSelectedVolunteers] = useState<SelectedVolunteer[]>([]);
  const [selectedVolunteer, setSelectedVolunteer] = useState<SelectedVolunteer | null>(null);
  const [contactMessage, setContactMessage] = useState('');
  const [isContactDialogOpen, setIsContactDialogOpen] = useState(false);

  useEffect(() => {
    // Mock selected volunteers data
    const mockSelectedVolunteers: SelectedVolunteer[] = [
      {
        id: '1',
        name: 'Alex Rodriguez',
        email: 'alex.rodriguez@email.com',
        location: 'New York, NY',
        rating: 4.9,
        totalEvents: 15,
        selectedDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        eventName: eventName,
        role: 'Technical Support Lead',
        status: 'confirmed',
        contractSigned: true,
        paymentAmount: 250,
        portfolio: {
          bio: 'Experienced technical volunteer with a passion for supporting innovative events and helping attendees navigate complex technical setups.',
          skills: ['Technical Support', 'Event Coordination', 'Public Speaking', 'Problem Solving', 'Network Setup'],
          languages: ['English', 'Spanish', 'Portuguese'],
          interests: ['Technology', 'Innovation', 'Education', 'Community Building'],
          experience: '5+ years of volunteer experience in technical events, including major tech conferences and startup showcases.',
          achievements: ['Top Volunteer 2023', 'Technical Excellence Award', 'Community Impact Recognition'],
          previousEvents: [
            { name: 'TechCrunch Disrupt 2023', role: 'Technical Lead', date: '2023-10-15', rating: 5.0 },
            { name: 'Startup Week NYC', role: 'AV Support', date: '2023-09-22', rating: 4.8 },
            { name: 'AI Innovation Summit', role: 'Tech Support', date: '2023-08-10', rating: 4.9 }
          ]
        }
      },
      {
        id: '2',
        name: 'Sarah Chen',
        email: 'sarah.chen@email.com',
        location: 'San Francisco, CA',
        rating: 4.7,
        totalEvents: 12,
        selectedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        eventName: eventName,
        role: 'Registration Coordinator',
        status: 'contacted',
        contractSigned: false,
        paymentAmount: 200,
        portfolio: {
          bio: 'Detail-oriented volunteer specializing in attendee registration and customer service with multilingual capabilities.',
          skills: ['Customer Service', 'Registration Systems', 'Data Management', 'Multilingual Communication'],
          languages: ['English', 'Mandarin', 'Cantonese', 'Japanese'],
          interests: ['Cultural Exchange', 'Technology', 'Professional Development', 'International Relations'],
          experience: '3+ years managing registration for large-scale international events with diverse attendee bases.',
          achievements: ['Customer Service Excellence Award', 'Multilingual Support Recognition'],
          previousEvents: [
            { name: 'Global Tech Forum 2023', role: 'Registration Lead', date: '2023-11-08', rating: 4.9 },
            { name: 'International Business Summit', role: 'Check-in Coordinator', date: '2023-09-15', rating: 4.6 },
            { name: 'Cultural Innovation Conference', role: 'Attendee Services', date: '2023-07-20', rating: 4.8 }
          ]
        }
      },
      {
        id: '3',
        name: 'Michael Thompson',
        email: 'michael.thompson@email.com',
        location: 'Austin, TX',
        rating: 4.8,
        totalEvents: 20,
        selectedDate: new Date(Date.now() - 3 * 60 * 60 * 1000),
        eventName: eventName,
        role: 'Event Setup Coordinator',
        status: 'selected',
        contractSigned: false,
        paymentAmount: 300,
        portfolio: {
          bio: 'Veteran event volunteer with extensive experience in logistics, setup, and venue management for major conferences.',
          skills: ['Event Logistics', 'Venue Setup', 'Team Leadership', 'Vendor Coordination', 'Safety Management'],
          languages: ['English', 'French'],
          interests: ['Event Production', 'Project Management', 'Team Building', 'Innovation'],
          experience: '7+ years in event production and volunteer coordination, specializing in large-scale technical conferences.',
          achievements: ['Volunteer Leadership Award', 'Outstanding Service Recognition', 'Safety Excellence Certificate'],
          previousEvents: [
            { name: 'SXSW Interactive 2023', role: 'Setup Lead', date: '2023-03-10', rating: 4.9 },
            { name: 'Austin Tech Week', role: 'Logistics Coordinator', date: '2023-05-18', rating: 4.7 },
            { name: 'Innovation Festival', role: 'Venue Manager', date: '2023-08-25', rating: 4.8 }
          ]
        }
      },
      {
        id: '4',
        name: 'Emily Davis',
        email: 'emily.davis@email.com',
        location: 'Seattle, WA',
        rating: 4.6,
        totalEvents: 8,
        selectedDate: new Date(Date.now() - 30 * 60 * 1000),
        eventName: eventName,
        role: 'Guest Relations Specialist',
        status: 'selected',
        contractSigned: false,
        paymentAmount: 180,
        portfolio: {
          bio: 'Enthusiastic volunteer with strong interpersonal skills, focused on creating exceptional attendee experiences.',
          skills: ['Guest Relations', 'Conflict Resolution', 'Event Coordination', 'Social Media', 'Public Relations'],
          languages: ['English', 'German'],
          interests: ['Hospitality', 'Networking', 'Professional Development', 'Community Engagement'],
          experience: '2+ years in guest relations and customer service, with a focus on creating welcoming environments.',
          achievements: ['Best Newcomer Award 2023', 'Guest Satisfaction Excellence'],
          previousEvents: [
            { name: 'Seattle Tech Meetup', role: 'Host Coordinator', date: '2023-12-05', rating: 4.7 },
            { name: 'Northwest Innovation Conference', role: 'Guest Services', date: '2023-10-30', rating: 4.5 },
            { name: 'Women in Tech Summit', role: 'Networking Facilitator', date: '2023-09-12', rating: 4.6 }
          ]
        }
      }
    ];

    setSelectedVolunteers(mockSelectedVolunteers);
  }, [eventName]);

  const handleContactVolunteer = (volunteer: SelectedVolunteer) => {
    setSelectedVolunteer(volunteer);
    setContactMessage(`Hi ${volunteer.name.split(' ')[0]},

We're excited to inform you that you've been selected for the ${volunteer.role} position at ${volunteer.eventName}!

We were impressed by your experience and skills, particularly your background in ${volunteer.portfolio.skills.slice(0, 2).join(' and ')}.

Please let us know if you're available and interested in this opportunity. We'll send over the contract details once confirmed.

Best regards,
Event Organizing Team`);
    setIsContactDialogOpen(true);
  };

  const sendMessage = () => {
    if (!selectedVolunteer || !contactMessage.trim()) {
      toast.error('Please enter a message');
      return;
    }

    // Update volunteer status
    setSelectedVolunteers(prev => 
      prev.map(vol => 
        vol.id === selectedVolunteer.id 
          ? { ...vol, status: 'contacted' as const }
          : vol
      )
    );

    toast.success(`Message sent to ${selectedVolunteer.name}`);
    setIsContactDialogOpen(false);
    setContactMessage('');
    setSelectedVolunteer(null);
  };

  const updateVolunteerStatus = (volunteerId: string, newStatus: SelectedVolunteer['status']) => {
    setSelectedVolunteers(prev => 
      prev.map(vol => 
        vol.id === volunteerId 
          ? { ...vol, status: newStatus }
          : vol
      )
    );
    toast.success('Status updated successfully');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'selected': return 'bg-blue-100 text-blue-800';
      case 'contacted': return 'bg-yellow-100 text-yellow-800';
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'declined': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const exportPortfolios = () => {
    const portfolioData = selectedVolunteers.map(vol => ({
      name: vol.name,
      email: vol.email,
      role: vol.role,
      status: vol.status,
      rating: vol.rating,
      skills: vol.portfolio.skills.join(', '),
      experience: vol.portfolio.experience
    }));
    
    console.log('Exporting portfolio data:', portfolioData);
    toast.success('Portfolio data exported successfully!');
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Selected Candidates Portfolio
            </CardTitle>
            <CardDescription>
              Manage your selected volunteers for {eventName}
            </CardDescription>
          </div>
          <Button variant="outline" onClick={exportPortfolios}>
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {selectedVolunteers.length === 0 ? (
          <div className="text-center py-8">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="mb-2">No volunteers selected yet</h3>
            <p className="text-muted-foreground">
              Selected volunteers will appear here when you choose candidates for your event
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-blue-600">{selectedVolunteers.length}</div>
                  <p className="text-sm text-muted-foreground">Total Selected</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-600">
                    {selectedVolunteers.filter(v => v.status === 'confirmed').length}
                  </div>
                  <p className="text-sm text-muted-foreground">Confirmed</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-yellow-600">
                    {selectedVolunteers.filter(v => v.status === 'contacted').length}
                  </div>
                  <p className="text-sm text-muted-foreground">Pending Response</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-purple-600">
                    {selectedVolunteers.filter(v => v.contractSigned).length}
                  </div>
                  <p className="text-sm text-muted-foreground">Contracts Signed</p>
                </CardContent>
              </Card>
            </div>

            {/* Volunteers List */}
            <div className="grid gap-4">
              {selectedVolunteers.map((volunteer, index) => (
                <motion.div
                  key={volunteer.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-4">
                          <Avatar className="h-12 w-12">
                            <AvatarFallback className="bg-blue-100 text-blue-600">
                              {volunteer.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <CardTitle className="text-lg">{volunteer.name}</CardTitle>
                            <CardDescription>
                              {volunteer.role} • {volunteer.location}
                            </CardDescription>
                            <div className="flex items-center gap-4 mt-1">
                              <div className="flex items-center gap-1">
                                <Star className="h-4 w-4 text-yellow-500" />
                                <span className="text-sm font-medium">{volunteer.rating}</span>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {volunteer.totalEvents} events
                              </span>
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm text-muted-foreground">
                                  Selected {volunteer.selectedDate.toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 items-end">
                          <Badge className={getStatusColor(volunteer.status)}>
                            {volunteer.status === 'selected' && <Users className="h-3 w-3 mr-1" />}
                            {volunteer.status === 'contacted' && <MessageSquare className="h-3 w-3 mr-1" />}
                            {volunteer.status === 'confirmed' && <CheckCircle className="h-3 w-3 mr-1" />}
                            {volunteer.status.charAt(0).toUpperCase() + volunteer.status.slice(1)}
                          </Badge>
                          {volunteer.contractSigned && (
                            <Badge variant="outline" className="text-green-600 border-green-300">
                              <FileText className="h-3 w-3 mr-1" />
                              Contract Signed
                            </Badge>
                          )}
                          {volunteer.paymentAmount && (
                            <span className="text-sm font-medium text-green-600">
                              ${volunteer.paymentAmount}
                            </span>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <h5 className="font-medium mb-2">Skills & Expertise</h5>
                          <div className="flex flex-wrap gap-1">
                            {volunteer.portfolio.skills.slice(0, 4).map((skill, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                            {volunteer.portfolio.skills.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{volunteer.portfolio.skills.length - 4} more
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div>
                          <h5 className="font-medium mb-2">Languages</h5>
                          <div className="flex flex-wrap gap-1">
                            {volunteer.portfolio.languages.map((language, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {language}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="mb-4">
                        <h5 className="font-medium mb-2">Bio</h5>
                        <p className="text-sm text-muted-foreground">
                          {volunteer.portfolio.bio}
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-2" />
                              View Portfolio
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle className="flex items-center gap-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarFallback>
                                    {volunteer.name.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                {volunteer.name} - Full Portfolio
                              </DialogTitle>
                              <DialogDescription>
                                Detailed profile and experience history
                              </DialogDescription>
                            </DialogHeader>
                            
                            <Tabs defaultValue="profile" className="w-full">
                              <TabsList className="grid w-full grid-cols-3">
                                <TabsTrigger value="profile">Profile</TabsTrigger>
                                <TabsTrigger value="experience">Experience</TabsTrigger>
                                <TabsTrigger value="events">Previous Events</TabsTrigger>
                              </TabsList>
                              
                              <TabsContent value="profile" className="space-y-4">
                                <div className="grid md:grid-cols-2 gap-4">
                                  <div>
                                    <h4 className="font-medium mb-2">Contact Information</h4>
                                    <div className="space-y-1 text-sm">
                                      <p><strong>Email:</strong> {volunteer.email}</p>
                                      <p><strong>Location:</strong> {volunteer.location}</p>
                                      <p><strong>Rating:</strong> {volunteer.rating}/5.0 ⭐</p>
                                    </div>
                                  </div>
                                  <div>
                                    <h4 className="font-medium mb-2">Statistics</h4>
                                    <div className="space-y-1 text-sm">
                                      <p><strong>Total Events:</strong> {volunteer.totalEvents}</p>
                                      <p><strong>Selected Role:</strong> {volunteer.role}</p>
                                      <p><strong>Payment:</strong> ${volunteer.paymentAmount}</p>
                                    </div>
                                  </div>
                                </div>
                                
                                <div>
                                  <h4 className="font-medium mb-2">Bio</h4>
                                  <p className="text-sm text-muted-foreground">{volunteer.portfolio.bio}</p>
                                </div>
                                
                                <div className="grid md:grid-cols-2 gap-4">
                                  <div>
                                    <h4 className="font-medium mb-2">Skills</h4>
                                    <div className="flex flex-wrap gap-1">
                                      {volunteer.portfolio.skills.map((skill, idx) => (
                                        <Badge key={idx} variant="secondary">{skill}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                  <div>
                                    <h4 className="font-medium mb-2">Interests</h4>
                                    <div className="flex flex-wrap gap-1">
                                      {volunteer.portfolio.interests.map((interest, idx) => (
                                        <Badge key={idx} variant="outline">{interest}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              </TabsContent>
                              
                              <TabsContent value="experience" className="space-y-4">
                                <div>
                                  <h4 className="font-medium mb-2">Experience Summary</h4>
                                  <p className="text-sm text-muted-foreground">{volunteer.portfolio.experience}</p>
                                </div>
                                
                                <div>
                                  <h4 className="font-medium mb-2">Achievements</h4>
                                  <ul className="space-y-2">
                                    {volunteer.portfolio.achievements.map((achievement, idx) => (
                                      <li key={idx} className="flex items-center gap-2 text-sm">
                                        <Award className="h-4 w-4 text-yellow-500" />
                                        {achievement}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              </TabsContent>
                              
                              <TabsContent value="events" className="space-y-4">
                                <div className="space-y-3">
                                  {volunteer.portfolio.previousEvents.map((event, idx) => (
                                    <Card key={idx}>
                                      <CardContent className="p-4">
                                        <div className="flex items-start justify-between">
                                          <div>
                                            <h5 className="font-medium">{event.name}</h5>
                                            <p className="text-sm text-muted-foreground">{event.role}</p>
                                            <p className="text-xs text-muted-foreground mt-1">
                                              {new Date(event.date).toLocaleDateString()}
                                            </p>
                                          </div>
                                          <div className="flex items-center gap-1">
                                            <Star className="h-4 w-4 text-yellow-500" />
                                            <span className="font-medium">{event.rating}</span>
                                          </div>
                                        </div>
                                      </CardContent>
                                    </Card>
                                  ))}
                                </div>
                              </TabsContent>
                            </Tabs>
                          </DialogContent>
                        </Dialog>

                        {volunteer.status === 'selected' && (
                          <Button 
                            size="sm"
                            onClick={() => handleContactVolunteer(volunteer)}
                          >
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Contact
                          </Button>
                        )}

                        {volunteer.status === 'contacted' && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateVolunteerStatus(volunteer.id, 'confirmed')}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Mark Confirmed
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Contact Dialog */}
        <Dialog open={isContactDialogOpen} onOpenChange={setIsContactDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                Contact {selectedVolunteer?.name}
              </DialogTitle>
              <DialogDescription>
                Send a message to discuss the volunteer opportunity
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  rows={8}
                  placeholder="Enter your message..."
                />
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button onClick={sendMessage} className="flex-1">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Send Message
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsContactDialogOpen(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}