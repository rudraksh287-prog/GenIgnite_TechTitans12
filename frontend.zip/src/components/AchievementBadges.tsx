import { useState, useEffect } from 'react';
import { Award, Star, Trophy, Crown, Medal, Zap, Target, Users, Calendar, DollarSign } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'participation' | 'milestone' | 'excellence' | 'community' | 'special';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  points: number;
  unlocked: boolean;
  unlockedDate?: Date;
  progress?: number;
  maxProgress?: number;
  requirements: string[];
}

interface AchievementBadgesProps {
  userRole: 'sponsor' | 'volunteer' | 'organizer';
  userStats?: {
    eventsParticipated: number;
    totalSpent?: number;
    totalEarned?: number;
    hoursVolunteered?: number;
    eventsOrganized?: number;
    satisfactionRating?: number;
  };
  isDarkMode?: boolean;
}

export default function AchievementBadges({ 
  userRole, 
  userStats = {
    eventsParticipated: 8,
    totalSpent: 25000,
    totalEarned: 450,
    hoursVolunteered: 120,
    eventsOrganized: 3,
    satisfactionRating: 4.8
  },
  isDarkMode 
}: AchievementBadgesProps) {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [totalPoints, setTotalPoints] = useState(0);

  useEffect(() => {
    let mockAchievements: Achievement[] = [];

    if (userRole === 'sponsor') {
      mockAchievements = [
        {
          id: '1',
          title: 'First Investment',
          description: 'Sponsored your first event',
          icon: '🎯',
          category: 'milestone',
          rarity: 'common',
          points: 100,
          unlocked: true,
          unlockedDate: new Date('2024-01-15'),
          requirements: ['Sponsor 1 event']
        },
        {
          id: '2',
          title: 'Generous Patron',
          description: 'Invested over $10,000 in events',
          icon: '💎',
          category: 'milestone',
          rarity: 'rare',
          points: 500,
          unlocked: true,
          unlockedDate: new Date('2024-02-20'),
          requirements: ['Spend $10,000+ on sponsorships']
        },
        {
          id: '3',
          title: 'Industry Leader',
          description: 'Sponsored 10 different events',
          icon: '👑',
          category: 'excellence',
          rarity: 'epic',
          points: 1000,
          unlocked: false,
          progress: userStats.eventsParticipated,
          maxProgress: 10,
          requirements: ['Sponsor 10 events', 'Maintain high satisfaction rating']
        },
        {
          id: '4',
          title: 'Community Champion',
          description: 'Supported 5 community/charity events',
          icon: '🏆',
          category: 'community',
          rarity: 'rare',
          points: 750,
          unlocked: false,
          progress: 3,
          maxProgress: 5,
          requirements: ['Sponsor 5 community events', 'Positive impact rating']
        },
        {
          id: '5',
          title: 'Innovation Catalyst',
          description: 'Sponsored 3 tech innovation events',
          icon: '⚡',
          category: 'excellence',
          rarity: 'rare',
          points: 600,
          unlocked: true,
          unlockedDate: new Date('2024-03-10'),
          requirements: ['Sponsor tech events', 'Support innovation initiatives']
        },
        {
          id: '6',
          title: 'Global Influence',
          description: 'Sponsored events across 5 different countries',
          icon: '🌍',
          category: 'special',
          rarity: 'legendary',
          points: 2000,
          unlocked: false,
          progress: 1,
          maxProgress: 5,
          requirements: ['International sponsorships', 'Cultural impact']
        }
      ];
    } else if (userRole === 'volunteer') {
      mockAchievements = [
        {
          id: '1',
          title: 'Helping Hand',
          description: 'Completed your first volunteer task',
          icon: '🤝',
          category: 'participation',
          rarity: 'common',
          points: 50,
          unlocked: true,
          unlockedDate: new Date('2024-01-10'),
          requirements: ['Complete 1 volunteer task']
        },
        {
          id: '2',
          title: 'Dedicated Helper',
          description: 'Volunteered for 50+ hours',
          icon: '⏰',
          category: 'milestone',
          rarity: 'rare',
          points: 400,
          unlocked: true,
          unlockedDate: new Date('2024-02-28'),
          requirements: ['Accumulate 50 volunteer hours']
        },
        {
          id: '3',
          title: 'Event Specialist',
          description: 'Volunteered for 10 different events',
          icon: '🎪',
          category: 'excellence',
          rarity: 'epic',
          points: 800,
          unlocked: false,
          progress: userStats.eventsParticipated,
          maxProgress: 10,
          requirements: ['Volunteer for 10 events', 'High performance rating']
        },
        {
          id: '4',
          title: 'Community Hero',
          description: 'Volunteered 100+ hours for community service',
          icon: '🦸',
          category: 'community',
          rarity: 'epic',
          points: 1000,
          unlocked: false,
          progress: userStats.hoursVolunteered || 0,
          maxProgress: 100,
          requirements: ['100 community service hours', 'Positive impact rating']
        },
        {
          id: '5',
          title: 'Tech Supporter',
          description: 'Specialized in technical event support',
          icon: '💻',
          category: 'excellence',
          rarity: 'rare',
          points: 500,
          unlocked: true,
          unlockedDate: new Date('2024-03-05'),
          requirements: ['Support 5 tech events', 'Technical skills certification']
        },
        {
          id: '6',
          title: 'Volunteer Legend',
          description: 'Reached legendary status in volunteering',
          icon: '🏆',
          category: 'special',
          rarity: 'legendary',
          points: 2500,
          unlocked: false,
          progress: 1250,
          maxProgress: 5000,
          requirements: ['5000 volunteer points', 'Outstanding contribution']
        }
      ];
    } else {
      mockAchievements = [
        {
          id: '1',
          title: 'Event Creator',
          description: 'Organized your first successful event',
          icon: '🎨',
          category: 'milestone',
          rarity: 'common',
          points: 200,
          unlocked: true,
          unlockedDate: new Date('2024-01-20'),
          requirements: ['Organize 1 successful event']
        },
        {
          id: '2',
          title: 'Master Organizer',
          description: 'Successfully organized 5 events',
          icon: '📅',
          category: 'excellence',
          rarity: 'rare',
          points: 750,
          unlocked: false,
          progress: userStats.eventsOrganized || 0,
          maxProgress: 5,
          requirements: ['Organize 5 events', 'High satisfaction rating']
        },
        {
          id: '3',
          title: 'Attendance Magnet',
          description: 'Organized an event with 1000+ attendees',
          icon: '🎯',
          category: 'excellence',
          rarity: 'epic',
          points: 1200,
          unlocked: false,
          progress: 500,
          maxProgress: 1000,
          requirements: ['1000+ event attendees', 'Successful execution']
        },
        {
          id: '4',
          title: 'Community Builder',
          description: 'Organized 3 community-focused events',
          icon: '🏘️',
          category: 'community',
          rarity: 'rare',
          points: 600,
          unlocked: true,
          unlockedDate: new Date('2024-02-15'),
          requirements: ['3 community events', 'Positive community impact']
        },
        {
          id: '5',
          title: 'Innovation Hub',
          description: 'Organized cutting-edge tech conferences',
          icon: '🚀',
          category: 'excellence',
          rarity: 'epic',
          points: 1000,
          unlocked: false,
          progress: 1,
          maxProgress: 3,
          requirements: ['3 tech conferences', 'Innovation recognition']
        },
        {
          id: '6',
          title: 'Event Visionary',
          description: 'Recognition as a top event organizer',
          icon: '🌟',
          category: 'special',
          rarity: 'legendary',
          points: 3000,
          unlocked: false,
          progress: 4.8,
          maxProgress: 5.0,
          requirements: ['5.0 satisfaction rating', 'Industry recognition']
        }
      ];
    }

    setAchievements(mockAchievements);
    
    // Calculate total points from unlocked achievements
    const points = mockAchievements
      .filter(achievement => achievement.unlocked)
      .reduce((sum, achievement) => sum + achievement.points, 0);
    setTotalPoints(points);
  }, [userRole, userStats]);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-gray-600 bg-gray-100 border-gray-200';
      case 'rare': return 'text-blue-600 bg-blue-100 border-blue-200';
      case 'epic': return 'text-purple-600 bg-purple-100 border-purple-200';
      case 'legendary': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'participation': return <Users className="h-4 w-4" />;
      case 'milestone': return <Target className="h-4 w-4" />;
      case 'excellence': return <Star className="h-4 w-4" />;
      case 'community': return <Users className="h-4 w-4" />;
      case 'special': return <Crown className="h-4 w-4" />;
      default: return <Award className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'participation': return 'text-green-600 bg-green-100';
      case 'milestone': return 'text-blue-600 bg-blue-100';
      case 'excellence': return 'text-purple-600 bg-purple-100';
      case 'community': return 'text-orange-600 bg-orange-100';
      case 'special': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const lockedAchievements = achievements.filter(a => !a.unlocked);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-600" />
          Achievement Badges
        </CardTitle>
        <CardDescription>
          Earn badges for your accomplishments on the platform
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="unlocked" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="unlocked">
              Earned ({unlockedAchievements.length})
            </TabsTrigger>
            <TabsTrigger value="locked">
              Available ({lockedAchievements.length})
            </TabsTrigger>
            <TabsTrigger value="stats">Stats</TabsTrigger>
          </TabsList>

          <TabsContent value="unlocked" className="space-y-4">
            {unlockedAchievements.length === 0 ? (
              <div className="text-center py-8">
                <Medal className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="mb-2">No badges earned yet</h3>
                <p className="text-muted-foreground">
                  Complete activities to earn your first achievement badge!
                </p>
              </div>
            ) : (
              <div className="grid gap-4">
                {unlockedAchievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="border-l-4 border-l-green-500 bg-green-50 dark:bg-green-900/20">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-3xl">{achievement.icon}</div>
                            <div>
                              <h4 className="font-medium">{achievement.title}</h4>
                              <p className="text-sm text-muted-foreground mb-2">
                                {achievement.description}
                              </p>
                              <div className="flex gap-2 mb-2">
                                <Badge className={getCategoryColor(achievement.category)}>
                                  {getCategoryIcon(achievement.category)}
                                  <span className="ml-1 capitalize">{achievement.category}</span>
                                </Badge>
                                <Badge className={`${getRarityColor(achievement.rarity)} border`}>
                                  {achievement.rarity.toUpperCase()}
                                </Badge>
                              </div>
                              {achievement.unlockedDate && (
                                <p className="text-xs text-green-600">
                                  Earned on {achievement.unlockedDate.toLocaleDateString()}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="bg-yellow-100 dark:bg-yellow-900/20 rounded-lg p-2 mb-2">
                              <Award className="h-5 w-5 text-yellow-600 mx-auto mb-1" />
                              <p className="text-sm font-medium">+{achievement.points}</p>
                              <p className="text-xs text-muted-foreground">points</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="locked" className="space-y-4">
            <div className="grid gap-4">
              {lockedAchievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="border-l-4 border-l-gray-300 opacity-75">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="text-3xl grayscale">{achievement.icon}</div>
                          <div>
                            <h4 className="font-medium">{achievement.title}</h4>
                            <p className="text-sm text-muted-foreground mb-2">
                              {achievement.description}
                            </p>
                            
                            {achievement.progress !== undefined && achievement.maxProgress && (
                              <div className="mb-2">
                                <div className="flex justify-between text-xs mb-1">
                                  <span>Progress</span>
                                  <span>{achievement.progress}/{achievement.maxProgress}</span>
                                </div>
                                <Progress 
                                  value={(achievement.progress / achievement.maxProgress) * 100} 
                                  className="h-2"
                                />
                              </div>
                            )}
                            
                            <div className="flex gap-2 mb-2">
                              <Badge className={getCategoryColor(achievement.category)}>
                                {getCategoryIcon(achievement.category)}
                                <span className="ml-1 capitalize">{achievement.category}</span>
                              </Badge>
                              <Badge className={`${getRarityColor(achievement.rarity)} border`}>
                                {achievement.rarity.toUpperCase()}
                              </Badge>
                            </div>
                            
                            <div>
                              <p className="text-xs font-medium mb-1">Requirements:</p>
                              <ul className="text-xs text-muted-foreground space-y-1">
                                {achievement.requirements.map((req, idx) => (
                                  <li key={idx} className="flex items-center gap-1">
                                    <Target className="h-3 w-3" />
                                    {req}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-2">
                            <Zap className="h-5 w-5 text-gray-500 mx-auto mb-1" />
                            <p className="text-sm font-medium text-gray-500">+{achievement.points}</p>
                            <p className="text-xs text-muted-foreground">points</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy className="h-5 w-5 text-yellow-600" />
                    <h3 className="font-medium">Total Achievement Points</h3>
                  </div>
                  <div className="text-2xl font-bold text-yellow-700">{totalPoints.toLocaleString()}</div>
                  <p className="text-sm text-muted-foreground">
                    From {unlockedAchievements.length} unlocked badges
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="h-5 w-5 text-purple-600" />
                    <h3 className="font-medium">Completion Rate</h3>
                  </div>
                  <div className="text-2xl font-bold text-purple-700">
                    {Math.round((unlockedAchievements.length / achievements.length) * 100)}%
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {unlockedAchievements.length} of {achievements.length} badges earned
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Achievement Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {['common', 'rare', 'epic', 'legendary'].map(rarity => {
                    const rarityAchievements = achievements.filter(a => a.rarity === rarity);
                    const unlockedInRarity = rarityAchievements.filter(a => a.unlocked).length;
                    
                    return (
                      <div key={rarity} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge className={getRarityColor(rarity)}>
                            {rarity.toUpperCase()}
                          </Badge>
                          <span className="text-sm">{unlockedInRarity}/{rarityAchievements.length}</span>
                        </div>
                        <Progress 
                          value={rarityAchievements.length > 0 ? (unlockedInRarity / rarityAchievements.length) * 100 : 0} 
                          className="h-2 w-32"
                        />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Your Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Events Participated:</span>
                    <p className="font-medium">{userStats.eventsParticipated}</p>
                  </div>
                  {userStats.totalSpent && (
                    <div>
                      <span className="text-muted-foreground">Total Invested:</span>
                      <p className="font-medium">${userStats.totalSpent.toLocaleString()}</p>
                    </div>
                  )}
                  {userStats.totalEarned && (
                    <div>
                      <span className="text-muted-foreground">Total Earned:</span>
                      <p className="font-medium">${userStats.totalEarned.toLocaleString()}</p>
                    </div>
                  )}
                  {userStats.hoursVolunteered && (
                    <div>
                      <span className="text-muted-foreground">Hours Volunteered:</span>
                      <p className="font-medium">{userStats.hoursVolunteered}</p>
                    </div>
                  )}
                  {userStats.eventsOrganized && (
                    <div>
                      <span className="text-muted-foreground">Events Organized:</span>
                      <p className="font-medium">{userStats.eventsOrganized}</p>
                    </div>
                  )}
                  {userStats.satisfactionRating && (
                    <div>
                      <span className="text-muted-foreground">Satisfaction Rating:</span>
                      <p className="font-medium">{userStats.satisfactionRating}/5.0 ⭐</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}