import { useState, useEffect } from 'react';
import { FileText, PenTool, Check, Clock, AlertCircle, Download, Eye, Send } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';

interface Contract {
  id: string;
  title: string;
  eventName: string;
  eventDate: string;
  parties: {
    organizer: string;
    counterparty: string;
    counterpartyRole: 'sponsor' | 'volunteer';
  };
  status: 'draft' | 'pending_signature' | 'signed' | 'expired' | 'cancelled';
  amount?: number;
  terms: string[];
  paymentTerms: string;
  createdDate: Date;
  signedDate?: Date;
  expiryDate: Date;
  digitalSignature?: {
    signed: boolean;
    signedBy?: string;
    signedAt?: Date;
  };
}

interface ContractManagerProps {
  userRole: 'sponsor' | 'volunteer' | 'organizer';
  userName: string;
  isDarkMode?: boolean;
}

export default function ContractManager({ userRole, userName, isDarkMode }: ContractManagerProps) {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [isSigningDialogOpen, setIsSigningDialogOpen] = useState(false);
  const [signatureAgreement, setSignatureAgreement] = useState(false);
  const [signatureComments, setSignatureComments] = useState('');

  // Mock contracts based on user role
  useEffect(() => {
    const mockContracts: Contract[] = [];

    if (userRole === 'sponsor') {
      mockContracts.push(
        {
          id: 'CNT-001',
          title: 'Gold Sponsorship Agreement',
          eventName: 'Tech Innovation Summit 2024',
          eventDate: '2024-03-15',
          parties: {
            organizer: 'TechCorp Events',
            counterparty: userName,
            counterpartyRole: 'sponsor'
          },
          status: 'pending_signature',
          amount: 10000,
          terms: [
            'Gold-tier sponsorship benefits including keynote speaking slot',
            'Logo placement on all event materials and website',
            'Dedicated exhibition booth (10x10 ft)',
            'Access to attendee contact list post-event',
            'Social media promotion and press release inclusion'
          ],
          paymentTerms: 'Payment due within 30 days of contract signature',
          createdDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
        },
        {
          id: 'CNT-002',
          title: 'Platinum Sponsorship Agreement',
          eventName: 'Corporate Leadership Conference',
          eventDate: '2024-04-22',
          parties: {
            organizer: 'Business Leaders Inc',
            counterparty: userName,
            counterpartyRole: 'sponsor'
          },
          status: 'signed',
          amount: 15000,
          terms: [
            'Platinum-tier sponsorship with title sponsor recognition',
            'Opening keynote presentation opportunity',
            'Premium booth location and enhanced branding',
            'Exclusive networking reception hosting rights',
            'Full attendee database access and marketing rights'
          ],
          paymentTerms: 'Payment due within 30 days of contract signature',
          createdDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          signedDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          expiryDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
          digitalSignature: {
            signed: true,
            signedBy: userName,
            signedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
          }
        }
      );
    } else if (userRole === 'volunteer') {
      mockContracts.push(
        {
          id: 'CNT-VOL-001',
          title: 'Volunteer Service Agreement',
          eventName: 'Tech Innovation Summit 2024',
          eventDate: '2024-03-15',
          parties: {
            organizer: 'TechCorp Events',
            counterparty: userName,
            counterpartyRole: 'volunteer'
          },
          status: 'pending_signature',
          amount: 200,
          terms: [
            'Event setup and registration assistance (8 hours)',
            'Technical support during conference sessions',
            'Attendee guidance and information services',
            'Post-event cleanup and equipment management',
            'Compensation of $200 upon successful completion'
          ],
          paymentTerms: 'Payment processed within 7 days after event completion',
          createdDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
          expiryDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000)
        },
        {
          id: 'CNT-VOL-002',
          title: 'Community Health Fair Volunteer Agreement',
          eventName: 'Community Health Fair',
          eventDate: '2024-04-08',
          parties: {
            organizer: 'Health First Organization',
            counterparty: userName,
            counterpartyRole: 'volunteer'
          },
          status: 'signed',
          amount: 150,
          terms: [
            'Health screening station assistance (6 hours)',
            'Visitor registration and information booth management',
            'Setup and breakdown of event facilities',
            'Compensation of $150 upon completion',
            'Certificate of community service hours'
          ],
          paymentTerms: 'Payment processed within 7 days after event completion',
          createdDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          signedDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
          expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          digitalSignature: {
            signed: true,
            signedBy: userName,
            signedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000)
          }
        }
      );
    } else {
      mockContracts.push(
        {
          id: 'CNT-ORG-001',
          title: 'Venue Rental Agreement',
          eventName: 'Annual Tech Conference 2024',
          eventDate: '2024-06-15',
          parties: {
            organizer: userName,
            counterparty: 'Convention Center Management',
            counterpartyRole: 'sponsor'
          },
          status: 'signed',
          amount: 25000,
          terms: [
            'Main conference hall rental for 2 days',
            'A/V equipment and technical support included',
            'Catering prep areas and storage access',
            'Parking allocation for 500 vehicles',
            'Setup and breakdown time included'
          ],
          paymentTerms: '50% deposit required, balance due 30 days before event',
          createdDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
          signedDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
          digitalSignature: {
            signed: true,
            signedBy: userName,
            signedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
          }
        }
      );
    }

    setContracts(mockContracts);
  }, [userRole, userName]);

  const handleSignContract = () => {
    if (!selectedContract || !signatureAgreement) {
      toast.error('Please accept the terms and conditions');
      return;
    }

    // Simulate contract signing
    const updatedContract = {
      ...selectedContract,
      status: 'signed' as const,
      signedDate: new Date(),
      digitalSignature: {
        signed: true,
        signedBy: userName,
        signedAt: new Date()
      }
    };

    setContracts(prev => 
      prev.map(contract => 
        contract.id === selectedContract.id ? updatedContract : contract
      )
    );

    toast.success('Contract signed successfully!');
    setIsSigningDialogOpen(false);
    setSelectedContract(null);
    setSignatureAgreement(false);
    setSignatureComments('');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft': return <FileText className="h-4 w-4" />;
      case 'pending_signature': return <PenTool className="h-4 w-4" />;
      case 'signed': return <Check className="h-4 w-4" />;
      case 'expired': return <Clock className="h-4 w-4" />;
      case 'cancelled': return <AlertCircle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'pending_signature': return 'bg-yellow-100 text-yellow-800';
      case 'signed': return 'bg-green-100 text-green-800';
      case 'expired': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Contract Management
        </CardTitle>
        <CardDescription>
          Digital contracts with secure signing and payment automation
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {contracts.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="mb-2">No contracts yet</h3>
            <p className="text-muted-foreground">
              Contracts will appear here when you engage with events
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {contracts.map((contract, index) => (
              <motion.div
                key={contract.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="border-l-4 border-l-blue-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{contract.title}</CardTitle>
                        <CardDescription>
                          {contract.eventName} • {formatDate(new Date(contract.eventDate))}
                        </CardDescription>
                      </div>
                      <Badge className={getStatusColor(contract.status)}>
                        {getStatusIcon(contract.status)}
                        <span className="ml-1 capitalize">{contract.status.replace('_', ' ')}</span>
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Organizer:</span> {contract.parties.organizer}
                      </div>
                      <div>
                        <span className="font-medium">Counterparty:</span> {contract.parties.counterparty}
                      </div>
                      {contract.amount && (
                        <div>
                          <span className="font-medium">Amount:</span> ${contract.amount.toLocaleString()}
                        </div>
                      )}
                      <div>
                        <span className="font-medium">Created:</span> {formatDate(contract.createdDate)}
                      </div>
                    </div>

                    <div>
                      <h5 className="font-medium mb-2">Key Terms:</h5>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {contract.terms.slice(0, 2).map((term, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <Check className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                            {term}
                          </li>
                        ))}
                        {contract.terms.length > 2 && (
                          <li className="text-xs text-muted-foreground">
                            + {contract.terms.length - 2} more terms...
                          </li>
                        )}
                      </ul>
                    </div>

                    <div className="text-sm">
                      <span className="font-medium">Payment Terms:</span>
                      <p className="text-muted-foreground mt-1">{contract.paymentTerms}</p>
                    </div>

                    {contract.digitalSignature?.signed && (
                      <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                        <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                          <Check className="h-4 w-4" />
                          <span className="font-medium">Digitally Signed</span>
                        </div>
                        <p className="text-sm text-green-600 dark:text-green-300 mt-1">
                          Signed by {contract.digitalSignature.signedBy} on {formatDate(contract.digitalSignature.signedAt!)}
                        </p>
                      </div>
                    )}

                    <div className="flex gap-2 pt-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSelectedContract(contract)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                      
                      {contract.status === 'pending_signature' && (
                        <Button 
                          size="sm"
                          onClick={() => {
                            setSelectedContract(contract);
                            setIsSigningDialogOpen(true);
                          }}
                        >
                          <PenTool className="h-4 w-4 mr-2" />
                          Sign Contract
                        </Button>
                      )}
                      
                      {contract.status === 'signed' && (
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Download PDF
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Contract Signing Dialog */}
        <Dialog open={isSigningDialogOpen} onOpenChange={setIsSigningDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <PenTool className="h-5 w-5" />
                Digital Contract Signature
              </DialogTitle>
              <DialogDescription>
                Please review and sign the contract electronically
              </DialogDescription>
            </DialogHeader>
            
            {selectedContract && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-2">{selectedContract.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {selectedContract.eventName} • Contract ID: {selectedContract.id}
                  </p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Contract Terms:</h4>
                  <ul className="space-y-2">
                    {selectedContract.terms.map((term, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <Check className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                        {term}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Payment Terms:</h4>
                  <p className="text-sm">{selectedContract.paymentTerms}</p>
                  {selectedContract.amount && (
                    <p className="text-sm font-medium mt-2">
                      Total Amount: ${selectedContract.amount.toLocaleString()}
                    </p>
                  )}
                </div>

                <div className="space-y-3">
                  <Label htmlFor="comments">Additional Comments (Optional)</Label>
                  <Textarea
                    id="comments"
                    placeholder="Any additional notes or comments..."
                    value={signatureComments}
                    onChange={(e) => setSignatureComments(e.target.value)}
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="agreement"
                    checked={signatureAgreement}
                    onCheckedChange={setSignatureAgreement}
                  />
                  <Label htmlFor="agreement" className="text-sm">
                    I have read, understood, and agree to all terms and conditions of this contract. 
                    I understand that this constitutes a legally binding digital signature.
                  </Label>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    onClick={handleSignContract}
                    disabled={!signatureAgreement}
                    className="flex-1"
                  >
                    <PenTool className="h-4 w-4 mr-2" />
                    Sign Contract Digitally
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsSigningDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}