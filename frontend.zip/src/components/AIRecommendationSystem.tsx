import { useState, useEffect } from 'react';
import { Brain, Star, Filter, TrendingUp, Users, MapPin, Calendar, Target, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface AIRecommendation {
  id: string;
  title: string;
  type: string;
  matchScore: number;
  reasons: string[];
  date: string;
  location: string;
  organizer: string;
  description: string;
  attendees: number;
  tags: string[];
  urgency: 'low' | 'medium' | 'high';
}

interface AIFilters {
  location: string[];
  eventTypes: string[];
  matchThreshold: number;
  includeNewTypes: boolean;
  prioritizeUrgent: boolean;
  maxDistance: number;
}

interface AIRecommendationSystemProps {
  userRole: 'sponsor' | 'volunteer' | 'organizer';
  userInterests?: string[];
  userSkills?: string[];
  userLocation?: string;
  isDarkMode?: boolean;
}

export default function AIRecommendationSystem({ 
  userRole, 
  userInterests = [], 
  userSkills = [], 
  userLocation = '',
  isDarkMode 
}: AIRecommendationSystemProps) {
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [filters, setFilters] = useState<AIFilters>({
    location: [],
    eventTypes: [],
    matchThreshold: 70,
    includeNewTypes: true,
    prioritizeUrgent: false,
    maxDistance: 50
  });
  const [isLearning, setIsLearning] = useState(false);

  // Mock AI recommendations based on user role and preferences
  useEffect(() => {
    setIsLearning(true);
    
    setTimeout(() => {
      const mockRecommendations: AIRecommendation[] = [];

      if (userRole === 'sponsor') {
        mockRecommendations.push(
          {
            id: '1',
            title: 'Green Tech Innovation Summit 2024',
            type: 'Tech Events',
            matchScore: 92,
            reasons: ['Matches your sustainability focus', 'High-ROI audience', 'Previous similar event success'],
            date: '2024-04-15',
            location: 'San Francisco, CA',
            organizer: 'GreenTech Alliance',
            description: 'Leading sustainable technology conference with 2000+ attendees',
            attendees: 2000,
            tags: ['sustainability', 'innovation', 'networking'],
            urgency: 'high'
          },
          {
            id: '2',
            title: 'Corporate Leadership Excellence Awards',
            type: 'Corporate Events',
            matchScore: 87,
            reasons: ['Executive audience alignment', 'Brand visibility opportunity', 'Industry recognition platform'],
            date: '2024-05-20',
            location: 'New York, NY',
            organizer: 'Business Excellence Institute',
            description: 'Annual awards ceremony celebrating corporate leadership',
            attendees: 800,
            tags: ['leadership', 'awards', 'corporate'],
            urgency: 'medium'
          },
          {
            id: '3',
            title: 'Emerging Markets Investment Forum',
            type: 'Finance Events',
            matchScore: 83,
            reasons: ['Investment focus match', 'Global audience', 'High-value networking'],
            date: '2024-06-10',
            location: 'Miami, FL',
            organizer: 'Global Investment Network',
            description: 'Investment opportunities in emerging markets',
            attendees: 500,
            tags: ['finance', 'investment', 'global'],
            urgency: 'low'
          }
        );
      } else if (userRole === 'volunteer') {
        mockRecommendations.push(
          {
            id: '1',
            title: 'Community Garden Festival',
            type: 'Community Events',
            matchScore: 95,
            reasons: ['Matches your environmental interests', 'Local to your area', 'Skills alignment: event coordination'],
            date: '2024-04-08',
            location: 'Portland, OR',
            organizer: 'Green Community Initiative',
            description: 'Annual festival promoting sustainable gardening and community involvement',
            attendees: 300,
            tags: ['environment', 'community', 'sustainability'],
            urgency: 'high'
          },
          {
            id: '2',
            title: 'Tech Skills Workshop for Youth',
            type: 'Education Events',
            matchScore: 88,
            reasons: ['Leverages your tech background', 'Educational impact', 'Evening schedule fits availability'],
            date: '2024-04-25',
            location: 'Seattle, WA',
            organizer: 'Youth Tech Foundation',
            description: 'Teaching coding and digital skills to underserved youth',
            attendees: 50,
            tags: ['education', 'technology', 'youth'],
            urgency: 'medium'
          },
          {
            id: '3',
            title: 'Annual Charity Run for Health',
            type: 'Sports Events',
            matchScore: 81,
            reasons: ['Physical activity interest', 'Charity cause alignment', 'Previous marathon experience'],
            date: '2024-05-15',
            location: 'Vancouver, BC',
            organizer: 'Health First Foundation',
            description: 'Marathon event supporting healthcare access initiatives',
            attendees: 1000,
            tags: ['sports', 'charity', 'health'],
            urgency: 'low'
          }
        );
      } else {
        mockRecommendations.push(
          {
            id: '1',
            title: 'Event Management Excellence Conference',
            type: 'Professional Development',
            matchScore: 93,
            reasons: ['Industry knowledge advancement', 'Networking with peers', 'Latest trends and tools'],
            date: '2024-04-12',
            location: 'Chicago, IL',
            organizer: 'Event Professionals Association',
            description: 'Annual conference for event industry professionals',
            attendees: 800,
            tags: ['professional', 'networking', 'education'],
            urgency: 'high'
          },
          {
            id: '2',
            title: 'Venue Partnership Expo',
            type: 'Trade Shows',
            matchScore: 86,
            reasons: ['Venue sourcing opportunities', 'Cost optimization potential', 'Regional vendor connections'],
            date: '2024-05-03',
            location: 'Las Vegas, NV',
            organizer: 'Venue Network Alliance',
            description: 'Expo connecting organizers with venues and suppliers',
            attendees: 1200,
            tags: ['venues', 'suppliers', 'partnerships'],
            urgency: 'medium'
          }
        );
      }

      setRecommendations(mockRecommendations);
      setIsLearning(false);
    }, 1500);
  }, [userRole, userInterests, userSkills, filters]);

  const handleEngagement = (recommendationId: string, action: 'interested' | 'not_interested' | 'applied') => {
    // Simulate AI learning from user interactions
    setIsLearning(true);
    setTimeout(() => {
      setIsLearning(false);
      // In a real app, this would update the recommendation algorithm
    }, 500);
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 80) return 'text-blue-600 bg-blue-100';
    if (score >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-gray-600 bg-gray-100';
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-purple-600" />
          AI-Powered Recommendations
          {isLearning && (
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="h-4 w-4 text-purple-600" />
            </motion.div>
          )}
        </CardTitle>
        <CardDescription>
          Personalized event suggestions based on your interests, skills, and engagement patterns
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="recommendations" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="recommendations">Smart Matches</TabsTrigger>
            <TabsTrigger value="filters">AI Preferences</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations" className="space-y-4">
            {isLearning ? (
              <div className="text-center py-8">
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="w-12 h-12 mx-auto mb-4 bg-purple-100 rounded-full flex items-center justify-center"
                >
                  <Brain className="h-6 w-6 text-purple-600" />
                </motion.div>
                <p className="text-muted-foreground">AI is analyzing your preferences...</p>
              </div>
            ) : (
              <div className="space-y-4">
                {recommendations.map((rec, index) => (
                  <motion.div
                    key={rec.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="border-l-4 border-l-purple-500">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="text-lg">{rec.title}</CardTitle>
                            <CardDescription className="flex items-center gap-4 mt-1">
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                {new Date(rec.date).toLocaleDateString()}
                              </span>
                              <span className="flex items-center gap-1">
                                <MapPin className="h-4 w-4" />
                                {rec.location}
                              </span>
                            </CardDescription>
                          </div>
                          <div className="flex flex-col gap-2 items-end">
                            <Badge className={`${getMatchScoreColor(rec.matchScore)}`}>
                              <Target className="h-3 w-3 mr-1" />
                              {rec.matchScore}% Match
                            </Badge>
                            <Badge variant="outline" className={`${getUrgencyColor(rec.urgency)}`}>
                              {rec.urgency} priority
                            </Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-sm text-muted-foreground">{rec.description}</p>
                        
                        <div className="space-y-2">
                          <h5 className="text-sm font-medium flex items-center gap-2">
                            <TrendingUp className="h-4 w-4" />
                            Why this matches you:
                          </h5>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            {rec.reasons.map((reason, idx) => (
                              <li key={idx} className="flex items-center gap-2">
                                <Star className="h-3 w-3 text-yellow-500" />
                                {reason}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{rec.attendees} expected attendees</span>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          {rec.tags.map((tag, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button 
                            size="sm" 
                            onClick={() => handleEngagement(rec.id, 'applied')}
                          >
                            {userRole === 'sponsor' ? 'Express Interest' : 
                             userRole === 'volunteer' ? 'Apply Now' : 'Learn More'}
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleEngagement(rec.id, 'interested')}
                          >
                            Save for Later
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleEngagement(rec.id, 'not_interested')}
                          >
                            Not Interested
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="filters" className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium">Match Threshold</Label>
                <div className="mt-2">
                  <Slider
                    value={[filters.matchThreshold]}
                    onValueChange={(value) => 
                      setFilters(prev => ({ ...prev, matchThreshold: value[0] }))
                    }
                    max={100}
                    min={50}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>50%</span>
                    <span>Current: {filters.matchThreshold}%</span>
                    <span>100%</span>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Maximum Distance (miles)</Label>
                <div className="mt-2">
                  <Slider
                    value={[filters.maxDistance]}
                    onValueChange={(value) => 
                      setFilters(prev => ({ ...prev, maxDistance: value[0] }))
                    }
                    max={500}
                    min={10}
                    step={10}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>10 mi</span>
                    <span>Current: {filters.maxDistance} miles</span>
                    <span>500 mi</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-sm font-medium">Include New Event Types</Label>
                  <p className="text-xs text-muted-foreground">
                    Allow AI to suggest events outside your usual preferences
                  </p>
                </div>
                <Switch
                  checked={filters.includeNewTypes}
                  onCheckedChange={(checked) => 
                    setFilters(prev => ({ ...prev, includeNewTypes: checked }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-sm font-medium">Prioritize Urgent Opportunities</Label>
                  <p className="text-xs text-muted-foreground">
                    Show time-sensitive events first
                  </p>
                </div>
                <Switch
                  checked={filters.prioritizeUrgent}
                  onCheckedChange={(checked) => 
                    setFilters(prev => ({ ...prev, prioritizeUrgent: checked }))
                  }
                />
              </div>

              <div className="pt-4 border-t">
                <h4 className="text-sm font-medium mb-2">AI Learning Status</h4>
                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Profile Completeness</span>
                    <span className="text-green-600">85%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Interaction History</span>
                    <span className="text-blue-600">12 events</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Prediction Accuracy</span>
                    <span className="text-purple-600">91%</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}